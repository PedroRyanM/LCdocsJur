/**
 * installer/build.js
 *
 * Gera o executável Windows (.exe) via `pkg`.
 * Execute com: node installer/build.js
 *
 * Pré-requisitos no computador de build:
 *   npm install -g pkg
 */

const { execSync } = require('child_process');
const path = require('path');
const fs   = require('fs');

const ROOT        = path.resolve(__dirname, '..');
const SERVER_DIR  = path.join(ROOT, 'server');
const CLIENT_DIST = path.join(ROOT, 'client', 'dist');
const OUT_DIR     = path.join(ROOT, 'dist');

function run(cmd, cwd = ROOT) {
  console.log(`\n▶ ${cmd}`);
  execSync(cmd, { stdio: 'inherit', cwd });
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

async function main() {
  console.log('\n╔══════════════════════════════════════╗');
  console.log('║  DocJur — Build para Windows (.exe)   ║');
  console.log('╚══════════════════════════════════════╝\n');

  ensureDir(OUT_DIR);

  // 1. Build React client
  console.log('\n[1/4] Build do cliente React…');
  run('npm run build -w client');

  // 2. Copy client dist into server so pkg can bundle it
  const serverPublic = path.join(SERVER_DIR, 'public');
  if (fs.existsSync(serverPublic)) fs.rmSync(serverPublic, { recursive: true });
  fs.cpSync(CLIENT_DIST, serverPublic, { recursive: true });
  console.log('      ✓ Client copiado para server/public');

  // 3. Package with pkg
  console.log('\n[2/4] Empacotando com pkg…');
  run(
    `pkg server/src/index.js --targets node18-win-x64 --output dist/DocJur.exe --assets "server/public/**,server/src/data/**"`,
    ROOT
  );
  console.log('      ✓ DocJur.exe gerado');

  // 4. Copy launcher batch
  console.log('\n[3/4] Copiando arquivos de suporte…');
  fs.copyFileSync(
    path.join(__dirname, 'launcher.bat'),
    path.join(OUT_DIR, 'Abrir DocJur.bat')
  );
  fs.copyFileSync(
    path.join(__dirname, 'INSTALACAO.md'),
    path.join(OUT_DIR, 'INSTALACAO.md')
  );
  console.log('      ✓ Arquivos de suporte copiados');

  console.log('\n[4/4] Pronto!\n');
  console.log(`  Saída: ${OUT_DIR}`);
  console.log('  Arquivos gerados:');
  fs.readdirSync(OUT_DIR).forEach(f => console.log(`    • ${f}`));
  console.log('\n⚠  Lembre-se: instale o wkhtmltopdf no Windows para exportar PDF.');
  console.log('   Download: https://wkhtmltopdf.org/downloads.html\n');
}

main().catch(e => { console.error(e); process.exit(1); });
