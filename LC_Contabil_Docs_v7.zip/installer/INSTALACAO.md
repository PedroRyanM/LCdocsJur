# LC Contábil Docs — Instruções de Instalação

## Requisitos

### Obrigatório
- **Nenhum** — o `LC Contábil Docs.exe` já inclui o Node.js e todas as dependências JavaScript.

### Para exportação de PDF (obrigatório apenas para PDF)
1. Baixe o **wkhtmltopdf** em: https://wkhtmltopdf.org/downloads.html
2. Escolha o instalador para Windows (64-bit)
3. Durante a instalação, **marque a opção "Add to PATH"**
4. Reinicie o computador (ou a sessão do terminal)

---

## Como usar

1. Dê dois cliques em **`Abrir LC Contábil Docs.bat`**
2. O servidor inicia automaticamente
3. O navegador abre em `http://localhost:3333`
4. Ao terminar, feche a janela do terminal (encerra o servidor)

---

## Estrutura da pasta

```
LC Contábil Docs.exe          → Aplicativo principal
Abrir LC Contábil Docs.bat    → Atalho de inicialização (use este)
INSTALACAO.md       → Este arquivo
```

---

## Solução de Problemas

**"O aplicativo não abre"**
- Verifique se a porta 3333 não está ocupada por outro programa
- Execute `LC Contábil Docs.exe` diretamente e veja a mensagem no terminal

**"PDF não exporta"**
- Confirme que o `wkhtmltopdf` está instalado e no PATH
- Abra o Prompt de Comando e teste: `wkhtmltopdf --version`

**"Erro ao abrir no navegador"**
- Aguarde mais alguns segundos e acesse manualmente: http://localhost:3333
