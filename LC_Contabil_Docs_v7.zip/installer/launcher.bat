@echo off
title LC Contábil Docs
echo.
echo  ╔══════════════════════════════════╗
echo  ║         LC Contábil Docs — Iniciando       ║
echo  ╚══════════════════════════════════╝
echo.

:: Inicia o servidor em background
start /B "" "%~dp0LC Contábil Docs.exe"

:: Aguarda o servidor subir
timeout /t 2 /nobreak >nul

:: Abre no navegador padrão
start "" http://localhost:3333

echo  Aplicativo aberto no navegador.
echo  Feche esta janela para encerrar o servidor.
echo.
pause
