# LC Contábil Docs — Sistema de Geração de Documentos Jurídicos

## Estrutura do Projeto (Monorepo)

```
lc-contabil-docs-v2/
├── server/                         # Back-end Express
│   └── src/
│       ├── index.js                # Entry point — inicializa Express
│       ├── config/
│       │   └── index.js            # Variáveis de ambiente e caminhos
│       ├── routes/
│       │   ├── index.js            # Monta todas as rotas em /api
│       │   ├── clausulas.js        # GET /api/clausulas
│       │   ├── cnae.js             # GET /api/cnae/search?q=...
│       │   ├── export.js           # POST /api/export/docx | /pdf
│       │   └── upload.js           # POST /api/upload/logo
│       ├── controllers/            # Handlers HTTP (sem lógica de negócio)
│       ├── services/
│       │   ├── docx.service.js     # Gera .docx via biblioteca docx
│       │   └── pdf.service.js      # Gera .pdf via wkhtmltopdf
│       ├── middleware/
│       │   ├── error.js            # Tratamento centralizado de erros
│       │   └── multer.js           # Upload de imagens (logos)
│       └── data/
│           ├── cnae.json           # 673 atividades CNAE 2.0
│           └── templates/
│               └── alteracao-contratual/
│                   ├── clausulas.js # Enum de cláusulas + textos padrão
│                   └── secoes.js   # Definição das seções do documento
│
├── client/                         # Front-end React + Vite
│   ├── index.html
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx                # Entry point React
│       ├── App.jsx                 # Layout raiz
│       ├── styles/
│       │   ├── tokens.css          # Design tokens (cores, espaçamento)
│       │   └── globals.css         # Reset + utilitários globais
│       ├── store/                  # Estado global Zustand
│       │   ├── documento.store.js  # Dados da empresa, logos, CNAEs
│       │   ├── socios.store.js     # Lista dinâmica de sócios
│       │   ├── clausulas.store.js  # Ordem, textos, editor
│       │   └── ui.store.js         # Seção ativa, toasts
│       ├── services/
│       │   └── api.js              # Fetch wrapper — todos os endpoints
│       ├── hooks/
│       │   ├── usePreviewVars.js   # Computa variáveis para preview/export
│       │   └── useExport.js        # Orquestra exportação DOCX e PDF
│       ├── constants/
│       │   └── ordinals.js         # Ordinais em PT-BR
│       └── components/
│           ├── ui/                 # Primitivos: Button, Field, Toast, SectionHeader
│           ├── layout/             # Header, NavTabs
│           ├── editor/
│           │   ├── FormPanel.jsx   # Painel esquerdo — troca seções
│           │   └── preview/
│           │       ├── DocPreview.jsx     # Renderizador do documento
│           │       ├── PreviewPanel.jsx   # Wrapper com toolbar
│           │       └── buildPrintHtml.js  # Gera HTML para PDF
│           ├── sections/           # EmpresaSection, LogosSection
│           ├── socios/             # SocioCard, SociosSection
│           ├── clausulas/          # ClausulaItem, ClausulaEditor, ClausulasSection
│           └── cnae/               # CNAESection — busca e seleção de CNAEs
│
├── installer/
│   ├── build.js          # Script de empacotamento (.exe)
│   ├── launcher.bat      # Atalho Windows
│   └── INSTALACAO.md     # Instruções para o usuário final
│
├── .env.example
├── .gitignore
├── package.json          # Workspace root
└── README.md
```

---

## Desenvolvimento

```bash
# 1. Clone e instale tudo
npm install

# 2. Copie as variáveis de ambiente
cp .env.example .env

# 3. Inicie em modo dev (servidor + cliente simultâneos)
npm run dev
```

- Cliente: http://localhost:5173 (Vite HMR)
- Servidor: http://localhost:3333

---

## Build para produção

```bash
npm run build
```

Gera `client/dist/` (estáticos) + prepara o servidor para servir em modo produção.

---

## Empacotamento (.exe Windows)

```bash
# Instale o pkg globalmente (apenas uma vez)
npm install -g pkg

# Gere o executável
npm run package:win
```

Saída em `dist/LC Contábil Docs.exe`.

> O PDF depende do `wkhtmltopdf` instalado no Windows.
> O DOCX não tem dependência externa nenhuma.

---

## Escalabilidade — Como adicionar novos documentos

1. Crie `server/src/data/templates/novo-documento/clausulas.js`
2. Crie `server/src/data/templates/novo-documento/secoes.js`
3. Adicione uma rota em `server/src/routes/` se necessário
4. No cliente, adicione uma nova aba em `NavTabs` e o componente de seção correspondente

---

## Stack

| Camada     | Tecnologia              |
|------------|-------------------------|
| Front-end  | React 18 + Vite         |
| Estado     | Zustand                 |
| DnD        | @dnd-kit                |
| Back-end   | Node.js + Express       |
| DOCX       | docx (npm)              |
| PDF        | wkhtmltopdf             |
| Desktop    | pkg (Node → .exe)       |
