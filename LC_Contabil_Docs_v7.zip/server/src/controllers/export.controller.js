'use strict';
const docxService = require('../services/docx.service');
const pdfService  = require('../services/pdf.service');

async function exportDocx(req, res, next) {
  try {
    const { data, clausulaOrder, clausulaTexts, logos } = req.body;
    const buffer = await docxService.generate({ data, clausulaOrder, clausulaTexts, logos });

    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'Content-Disposition': 'attachment; filename="alteracao_contratual.docx"',
    });
    res.send(buffer);
  } catch (err) {
    next(err);
  }
}

async function exportPdf(req, res, next) {
  try {
    const { html } = req.body;
    if (!html) return res.status(400).json({ error: 'HTML ausente' });
    const pdfBuffer = await pdfService.generate(html);

    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': 'attachment; filename="alteracao_contratual.pdf"',
    });
    res.send(pdfBuffer);
  } catch (err) {
    next(err);
  }
}

module.exports = { exportDocx, exportPdf };
