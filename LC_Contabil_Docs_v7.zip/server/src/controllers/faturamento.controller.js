'use strict';
const faturamentoDocx = require('../services/faturamento-docx.service');
const { MESES_PT }    = require('../data/templates/declaracao-faturamento/template');

function getMeta(req, res) {
  res.json({ meses_pt: MESES_PT });
}

async function exportDocx(req, res, next) {
  try {
    const buffer = await faturamentoDocx.generate(req.body);
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'Content-Disposition': 'attachment; filename="declaracao_faturamento.docx"',
    });
    res.send(buffer);
  } catch (err) {
    next(err);
  }
}

module.exports = { getMeta, exportDocx };
