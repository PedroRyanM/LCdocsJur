'use strict';

function uploadLogo(req, res) {
  if (!req.file) {
    return res.status(400).json({ error: 'Nenhum arquivo recebido' });
  }
  const base64 = req.file.buffer.toString('base64');
  res.json({ base64, mimetype: req.file.mimetype });
}

module.exports = { uploadLogo };
