'use strict';
const { CLAUSULAS, DEFAULT_ORDER } = require('../data/templates/alteracao-contratual/clausulas');
const { SECOES } = require('../data/templates/alteracao-contratual/secoes');

function list(req, res) {
  res.json({ clausulas: CLAUSULAS, secoes: SECOES, defaultOrder: DEFAULT_ORDER });
}

module.exports = { list };
