'use strict';
const path = require('path');
const CNAE_DATA = require('../data/cnae.json');

// Normalize text for fuzzy search (remove accents, lowercase)
function normalize(str) {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

// Pre-build a normalized index at startup for fast search
const INDEX = CNAE_DATA.map(item => ({
  ...item,
  _search: normalize(`${item.codigo} ${item.denominacao} ${item.breadcrumb}`),
}));

function search(req, res) {
  const query = (req.query.q || '').trim();
  const limit = Math.min(parseInt(req.query.limit || '30', 10), 100);

  if (!query || query.length < 2) {
    return res.json({ results: [], total: 0 });
  }

  const terms = normalize(query).split(/\s+/).filter(Boolean);

  const results = INDEX.filter(item =>
    terms.every(term => item._search.includes(term))
  )
    .slice(0, limit)
    .map(({ _search, ...item }) => item); // strip internal field

  res.json({ results, total: results.length });
}

function listAll(req, res) {
  res.json({ results: CNAE_DATA, total: CNAE_DATA.length });
}

module.exports = { search, listAll };
