'use strict';
const path = require('path');

module.exports = {
  port:     parseInt(process.env.SERVER_PORT || '3333', 10),
  nodeEnv:  process.env.NODE_ENV || 'development',
  isProd:   process.env.NODE_ENV === 'production',

  paths: {
    data:         path.join(__dirname, '../data'),
    clientBuild:  path.join(__dirname, '../../client/dist'),
    tmp:          require('os').tmpdir(),
  },

  pdf: {
    // wkhtmltopdf binary — override via env if installed in custom path
    binary: process.env.WKHTMLTOPDF_BIN || 'wkhtmltopdf',
    args: [
      '--page-size', 'A4',
      '--margin-top',    '20mm',
      '--margin-bottom', '20mm',
      '--margin-left',   '20mm',
      '--margin-right',  '20mm',
      '--encoding',      'utf-8',
      '--disable-smart-shrinking',
      '--print-media-type',
    ],
  },
};
