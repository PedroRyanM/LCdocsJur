'use strict';

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, BorderStyle, WidthType, ShadingType, ImageRun,
  UnderlineType, HeadingLevel,
} = require('docx');

const MESES_PT = [
  'Janeiro','Fevereiro','Março','Abril','Maio','Junho',
  'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro',
];

function run(text, opts = {}) {
  return new TextRun({
    text,
    bold:    opts.bold    || false,
    italics: opts.italic  || false,
    size:    opts.size    || 22,
    font:    'Arial',
    color:   opts.color   || '000000',
  });
}

function para(children, opts = {}) {
  return new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    spacing:   { before: opts.before || 80, after: opts.after || 80, line: 360 },
    children,
  });
}

function borderNone() {
  const s = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
  return { top: s, bottom: s, left: s, right: s };
}

function borderThin() {
  const s = { style: BorderStyle.SINGLE, size: 4, color: '000000' };
  return { top: s, bottom: s, left: s, right: s };
}

function headerCell(text, width) {
  return new TableCell({
    width:    { size: width, type: WidthType.DXA },
    shading:  { fill: '903010', type: ShadingType.CLEAR },
    borders:  borderThin(),
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 60, after: 60 },
      children: [new TextRun({ text, bold: true, size: 20, font: 'Arial', color: 'FFFFFF' })],
    })],
  });
}

function dataCell(text, width, bold = false, align = AlignmentType.CENTER, shade = null) {
  return new TableCell({
    width:    { size: width, type: WidthType.DXA },
    shading:  shade ? { fill: shade, type: ShadingType.CLEAR } : undefined,
    borders:  borderThin(),
    children: [new Paragraph({
      alignment: align,
      spacing: { before: 60, after: 60 },
      children: [new TextRun({ text, bold, size: 20, font: 'Arial', color: '000000' })],
    })],
  });
}

function formatCurrency(val) {
  if (!val && val !== 0) return '';
  const num = parseFloat(String(val).replace(/[^\d,.-]/g, '').replace(',', '.'));
  if (isNaN(num)) return val;
  return `R$ ${num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function calcTotal(meses) {
  return meses.reduce((acc, m) => {
    const num = parseFloat(String(m.valor || '0').replace(/[^\d,.-]/g, '').replace(',', '.'));
    return acc + (isNaN(num) ? 0 : num);
  }, 0);
}

async function generate(data) {
  const {
    empresa_nome, empresa_endereco, empresa_cidade, empresa_cnpj,
    meses = [], assinatura_socio, assinatura_contador, contador_crc,
    cidade_assinatura, data_assinatura, logo,
  } = data;

  const total = calcTotal(meses);

  const children = [];

  // ── Logo ────────────────────────────────────────────────────
  if (logo && logo.base64) {
    try {
      const imgBuf = Buffer.from(logo.base64, 'base64');
      const ext    = (logo.mimetype || 'image/png').split('/')[1] || 'png';
      children.push(new Paragraph({
        alignment: AlignmentType.LEFT,
        spacing:   { before: 0, after: 200 },
        children:  [new ImageRun({
          data:           imgBuf,
          transformation: { width: 140, height: 60 },
          type:           ext,
        })],
      }));
    } catch (_) { /* skip if image fails */ }
  }

  // ── Title ──────────────────────────────────────────────────
  children.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 300, line: 360 },
    children: [new TextRun({
      text: 'DEMONSTRATIVO DE PREVISÃO DE FATURAMENTO',
      bold: true, size: 26, font: 'Arial', color: '903010',
      underline: { type: UnderlineType.SINGLE },
    })],
  }));

  // ── Company info table ──────────────────────────────────────
  const infoRows = [
    ['Empresa:', empresa_nome || ''],
    ['Endereço:', empresa_endereco || ''],
    ['Cidade:', empresa_cidade || ''],
    ['CNPJ:', empresa_cnpj || ''],
  ];

  const infoTable = new Table({
    width: { size: 9026, type: WidthType.DXA },
    columnWidths: [1800, 7226],
    rows: infoRows.map(([label, value]) => new TableRow({
      children: [
        new TableCell({
          width:   { size: 1800, type: WidthType.DXA },
          shading: { fill: 'F5EAD8', type: ShadingType.CLEAR },
          borders: borderThin(),
          children: [new Paragraph({
            spacing: { before: 60, after: 60 },
            children: [new TextRun({ text: label, bold: true, size: 20, font: 'Arial' })],
          })],
        }),
        new TableCell({
          width:   { size: 7226, type: WidthType.DXA },
          borders: borderThin(),
          children: [new Paragraph({
            spacing: { before: 60, after: 60 },
            children: [new TextRun({ text: value, bold: true, size: 20, font: 'Arial' })],
          })],
        }),
      ],
    })),
  });
  children.push(infoTable);
  children.push(para([], { before: 200, after: 80 }));

  // ── Declaration text ────────────────────────────────────────
  children.push(para([
    run('Declaro para fins de direito que a empresa qualificada acima declara os seguintes faturamentos dos '),
    run(`${meses.length}`, { bold: true }),
    run(' meses, conforme demonstrados abaixo:'),
  ], { before: 100, after: 200 }));

  // ── Months table ────────────────────────────────────────────
  const mesHeaderRow = new TableRow({
    children: [
      headerCell('MÊS',   2500),
      headerCell('ANO',   2000),
      headerCell('VALOR', 4526),
    ],
    tableHeader: true,
  });

  const mesRows = meses.map((m, idx) => new TableRow({
    children: [
      dataCell(m.mes  || '', 2500, false, AlignmentType.CENTER, idx % 2 ? 'F2F2F2' : null),
      dataCell(m.ano  || '', 2000, false, AlignmentType.CENTER, idx % 2 ? 'F2F2F2' : null),
      dataCell(formatCurrency(m.valor), 4526, false, AlignmentType.RIGHT, idx % 2 ? 'F2F2F2' : null),
    ],
  }));

  const totalRow = new TableRow({
    children: [
      new TableCell({
        columnSpan: 2,
        width:      { size: 4500, type: WidthType.DXA },
        shading:    { fill: '903010', type: ShadingType.CLEAR },
        borders:    borderThin(),
        children:   [new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 60, after: 60 },
          children: [new TextRun({ text: 'Totais', bold: true, size: 22, font: 'Arial', color: 'FFFFFF' })],
        })],
      }),
      new TableCell({
        width:   { size: 4526, type: WidthType.DXA },
        shading: { fill: '903010', type: ShadingType.CLEAR },
        borders: borderThin(),
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          spacing: { before: 60, after: 60 },
          children: [new TextRun({
            text:  formatCurrency(total),
            bold:  true,
            size:  22,
            font:  'Arial',
            color: 'FFFFFF',
          })],
        })],
      }),
    ],
  });

  const monthsTable = new Table({
    width: { size: 9026, type: WidthType.DXA },
    columnWidths: [2500, 2000, 4526],
    rows: [mesHeaderRow, ...mesRows, totalRow],
  });
  children.push(monthsTable);
  children.push(para([], { before: 400, after: 80 }));

  // ── Signatures ──────────────────────────────────────────────
  const sigCells = [];

  if (assinatura_socio) {
    const nomeSocio = data.socio_nome || '';
    sigCells.push(new TableCell({
      width:   { size: 4513, type: WidthType.DXA },
      borders: borderNone(),
      children: [
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 40 },
          children: [new TextRun({ text: '____________________________________________', size: 20, font: 'Arial' })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 20 },
          children: [new TextRun({ text: nomeSocio.toUpperCase() || 'SÓCIO/ADMINISTRADOR', bold: true, size: 20, font: 'Arial' })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 0 },
          children: [new TextRun({ text: 'Sócio/Administrador', size: 20, font: 'Arial' })] }),
      ],
    }));
  }

  if (assinatura_socio && assinatura_contador) {
    sigCells.push(new TableCell({
      width: { size: 0, type: WidthType.DXA },
      borders: borderNone(),
      children: [para([])],
    }));
  }

  if (assinatura_contador) {
    const crc = contador_crc ? `CRC: ${contador_crc}` : 'CRC: ___________';
    sigCells.push(new TableCell({
      width:   { size: 4513, type: WidthType.DXA },
      borders: borderNone(),
      children: [
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 40 },
          children: [new TextRun({ text: '____________________________________________', size: 20, font: 'Arial' })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 20 },
          children: [new TextRun({ text: 'Contador Responsável', bold: true, size: 20, font: 'Arial' })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 0 },
          children: [new TextRun({ text: crc, size: 20, font: 'Arial' })] }),
      ],
    }));
  }

  if (sigCells.length > 0) {
    children.push(new Table({
      width: { size: 9026, type: WidthType.DXA },
      rows: [new TableRow({ children: sigCells })],
    }));
  }

  children.push(para([], { before: 200, after: 80 }));

  // ── Closing statement + date ────────────────────────────────
  children.push(para([
    run('Por ser verdade, passo e firmo a presente declaração.'),
  ], { before: 100, after: 200 }));

  children.push(para([
    run(`${cidade_assinatura || 'Goiânia'}/Goiás, ${data_assinatura || '_____ de _____________ de 2025'}.`),
  ], { align: AlignmentType.RIGHT }));

  // ── Build document ──────────────────────────────────────────
  const doc = new Document({
    styles: {
      default: { document: { run: { font: 'Arial', size: 22 } } },
    },
    sections: [{
      properties: {
        page: {
          size:   { width: 11906, height: 16838 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
      },
      children,
    }],
  });

  return Packer.toBuffer(doc);
}

module.exports = { generate, MESES_PT: require('../data/templates/declaracao-faturamento/template').MESES_PT };
