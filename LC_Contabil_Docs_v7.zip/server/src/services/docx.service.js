'use strict';

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, BorderStyle, WidthType, ImageRun, UnderlineType,
} = require('docx');

const { CLAUSULAS } = require('../data/templates/alteracao-contratual/clausulas');

// ── Ordinals ──────────────────────────────────────────────────────────────────
const ORDINAL = [
  '', 'PRIMEIRA', 'SEGUNDA', 'TERCEIRA', 'QUARTA', 'QUINTA',
  'SEXTA', 'SÉTIMA', 'OITAVA', 'NONA', 'DÉCIMA',
  'DÉCIMA PRIMEIRA', 'DÉCIMA SEGUNDA', 'DÉCIMA TERCEIRA', 'DÉCIMA QUARTA', 'DÉCIMA QUINTA',
  'DÉCIMA SEXTA', 'DÉCIMA SÉTIMA', 'DÉCIMA OITAVA', 'DÉCIMA NONA', 'VIGÉSIMA',
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function run(text, opts = {}) {
  return new TextRun({
    text,
    bold:    opts.bold    || false,
    italics: opts.italic  || false,
    size:    opts.size    || 22,          // half-points → 11pt
    font:    'Times New Roman',
    color:   opts.color   || '1a1410',
    underline: opts.underline ? { type: UnderlineType.SINGLE } : undefined,
  });
}

function para(children, opts = {}) {
  return new Paragraph({
    alignment: opts.align  || AlignmentType.JUSTIFIED,
    spacing:   { before: opts.before || 120, after: opts.after || 120, line: 360 },
    indent:    opts.indent ? { left: 720 } : undefined,
    children,
  });
}

function resolveVars(text, vars) {
  return text.replace(/\{\{(\w+)\}\}/g, (_, k) => vars[k] || `[${k}]`);
}

function buildVars(data) {
  const socios = data.socios || [];
  const sede   = [
    data.sede_endereco, data.sede_bairro, data.sede_cidade, data.sede_uf,
    data.sede_cep ? `CEP ${data.sede_cep}` : '',
  ].filter(Boolean).join(', ');
  const admins = socios.filter(s => s.admin === 'sim').map(s => s.nome).filter(Boolean).join(', ');

  return {
    empresa_nome_atual: data.empresa_nome_atual || '',
    empresa_nome_novo:  data.empresa_nome_novo  || '',
    empresa_fantasia:   data.empresa_fantasia   || '',
    empresa_cnpj:       data.empresa_cnpj       || '',
    empresa_nire:       data.empresa_nire       || '',
    sede_completa:      sede,
    cap_quotas:         data.cap_quotas         || '',
    cap_valor_quota:    data.cap_valor_quota    || '',
    cap_total:          data.cap_total          || '',
    objeto_social:      data.objeto_social      || '',
    data_inicio:        data.data_inicio        || '',
    data_assinatura:    data.data_assinatura    || '',
    cidade_assinatura:  data.cidade_assinatura  || '',
    foro:               data.foro               || '',
    admins,
  };
}

// ── Logo row ──────────────────────────────────────────────────────────────────
function buildLogoRow(logos) {
  if (!logos || (!logos.client && !logos.contab)) return null;

  const makeCell = (logo, align) => {
    const children = logo
      ? [new Paragraph({
          alignment: align,
          children: [new ImageRun({
            data: Buffer.from(logo.base64, 'base64'),
            transformation: { width: 110, height: 55 },
            type: (logo.mimetype || 'image/png').split('/')[1],
          })],
        })]
      : [para([])];

    return new TableCell({
      width: { size: 4400, type: WidthType.DXA },
      borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } },
      children,
    });
  };

  return new Table({
    width: { size: 9026, type: WidthType.DXA },
    columnWidths: [4400, 226, 4400],
    rows: [new TableRow({
      children: [
        makeCell(logos.client,  AlignmentType.LEFT),
        new TableCell({
          width: { size: 226, type: WidthType.DXA },
          borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } },
          children: [para([])],
        }),
        makeCell(logos.contab, AlignmentType.RIGHT),
      ],
    })],
  });
}

// ── Document builder ──────────────────────────────────────────────────────────
async function generate({ data, clausulaOrder, clausulaTexts = {}, logos }) {
  const vars   = buildVars(data);
  const socios = data.socios || [];
  const children = [];

  // Logos
  const logoRow = buildLogoRow(logos);
  if (logoRow) { children.push(logoRow); children.push(para([], { before: 200, after: 0 })); }

  // Title block
  children.push(para([run('ALTERAÇÃO DO CONTRATO SOCIAL DE', { bold: true, size: 24 })],          { align: AlignmentType.CENTER, before: 0, after: 60 }));
  children.push(para([run((vars.empresa_nome_atual || '[EMPRESA]').toUpperCase(), { bold: true, size: 24 })], { align: AlignmentType.CENTER, before: 0, after: 60 }));
  children.push(para([run(vars.empresa_cnpj || '[CNPJ]', { size: 18, color: '7a7068' })],         { align: AlignmentType.CENTER, before: 0, after: 280 }));

  // Counters per section
  const counters  = { ALTERACAO: 0, CONTRATO: 0 };
  let   prevSecao = null;

  for (const clausulaId of (clausulaOrder || [])) {
    const def = CLAUSULAS[clausulaId];
    if (!def) continue;

    // Section bridge (Seção II)
    if (def.secao === 'CONTRATO' && prevSecao !== 'CONTRATO') {
      children.push(para([
        run('Em face das alterações acima, transcrevo o contrato social, nos termos da Lei n° 10.406/2002, mediante as condições e cláusulas seguintes:', { italic: true }),
      ], { before: 200, after: 160 }));
    }
    prevSecao = def.secao;

    // ── ABERTURA (special rendering) ──────────────────────────────────
    if (clausulaId === 'ABERTURA') {
      for (const s of socios) {
        const parts = [run(s.nome ? s.nome.toUpperCase() : '[SÓCIO]', { bold: true })];
        const desc = [
          s.nacionalidade ? `, nacionalidade ${s.nacionalidade}` : '',
          s.nascimento    ? `, nascido em ${s.nascimento}` : '',
          s.estado_civil  ? `, ${s.estado_civil}` : '',
          s.regime        ? ` pelo regime de ${s.regime}` : '',
          s.profissao     ? `, ${s.profissao}` : '',
          s.cpf           ? `, CPF nº ${s.cpf}` : '',
          s.rg            ? `, RG nº ${s.rg}` : '',
          s.endereco      ? `, residente e domiciliado na ${s.endereco}` : '',
          ', BRASIL.',
        ].join('');
        parts.push(run(desc));
        children.push(para(parts));
      }
      if (!socios.length) children.push(para([run('[Qualificação dos sócios]')]));

      const nomeSocios = socios.map(s => s.nome || '[SÓCIO]').join(', ');
      children.push(para([
        run(`${nomeSocios}, sócio(s) da empresa: `),
        run(vars.empresa_nome_atual || '[EMPRESA]', { bold: true }),
        run(`, devidamente registrado nesta Junta Comercial do Estado de Goiás, sob NIRE nº ${vars.empresa_nire || '[NIRE]'}, com sede na ${vars.sede_completa || '[SEDE]'}, devidamente inscrita no CNPJ/MF sob o nº ${vars.empresa_cnpj || '[CNPJ]'}, resolve neste ato transformar seu Registro de Empresário em Sociedade Empresarial Limitada - LTDA, nos termos da Lei n° 10.406/2002 mediante as condições estabelecidas nas cláusulas seguintes:`),
      ]));
      continue;
    }

    // ── NUMBERED CLAUSE ───────────────────────────────────────────────
    if (def.numerada) {
      counters[def.secao] = (counters[def.secao] || 0) + 1;
      const ordinal     = ORDINAL[counters[def.secao]] || `${counters[def.secao]}ª`;
      const clauseLabel = `CLÁUSULA ${ordinal}. `;
      const rawText     = clausulaTexts[clausulaId] !== undefined ? clausulaTexts[clausulaId] : def.texto;
      const resolved    = resolveVars(rawText, vars);
      const lines       = resolved.split('\n').filter(l => l.trim());

      // Special: capital social includes per-socio distribution
      if (clausulaId === 'CAPITAL_SOCIAL') {
        children.push(para([run(clauseLabel, { bold: true }), run(lines[0] || '')]));
        for (const s of socios) {
          children.push(para([
            run(s.nome ? s.nome.toUpperCase() : '[SÓCIO]', { bold: true }),
            run(` com ${s.quotas || '[QUOTAS]'} quotas perfazendo o valor de R$ ${s.quotas_valor || '[VALOR]'}, integralizado em moeda corrente do país.`),
          ], { indent: true }));
        }
        for (let i = 1; i < lines.length; i++) {
          children.push(para([run(lines[i])], { indent: true }));
        }
        continue;
      }

      lines.forEach((line, idx) => {
        if (idx === 0) {
          children.push(para([run(clauseLabel, { bold: true }), run(line)]));
        } else if (/^[§Pp]/.test(line)) {
          children.push(para([run(line)], { indent: true }));
        } else {
          children.push(para([run(line)]));
        }
      });
    }
  }

  // Date
  children.push(para([run(`${vars.cidade_assinatura || '[Cidade]'}, ${vars.data_assinatura || '[Data]'}.`, { color: '7a7068', italic: true })],
    { align: AlignmentType.RIGHT, before: 300, after: 0 }));

  // Signatures
  const sigSocios = socios.length ? socios : [{ nome: '', admin: 'sim' }];
  for (const s of sigSocios) {
    children.push(para([], { before: 600, after: 40 }));
    children.push(new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: 30, line: 240 },
      border: { top: { style: BorderStyle.SINGLE, size: 6, color: '555555', space: 1 } },
      children: [],
    }));
    children.push(para([run(s.nome ? s.nome.toUpperCase() : '[SÓCIO]', { bold: true, size: 20 })], { align: AlignmentType.CENTER, before: 0, after: 20 }));
    children.push(para([run(s.admin === 'sim' ? 'Sócio e Administrador' : 'Sócio', { size: 18, color: '7a7068' })], { align: AlignmentType.CENTER, before: 0 }));
  }

  const doc = new Document({
    styles: {
      default: { document: { run: { font: 'Times New Roman', size: 22 } } },
    },
    sections: [{
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
      },
      children,
    }],
  });

  return Packer.toBuffer(doc);
}

module.exports = { generate };
