'use strict';
const { execFile }  = require('child_process');
const { promisify } = require('util');
const fs   = require('fs');
const path = require('path');
const os   = require('os');
const cfg  = require('../config');

const execFileAsync = promisify(execFile);

async function generate(html) {
  const ts     = Date.now();
  const tmpIn  = path.join(cfg.paths.tmp, `docjur_${ts}.html`);
  const tmpOut = path.join(cfg.paths.tmp, `docjur_${ts}.pdf`);

  try {
    fs.writeFileSync(tmpIn, html, 'utf8');

    const args = [...cfg.pdf.args, tmpIn, tmpOut];
    await execFileAsync(cfg.pdf.binary, args, { timeout: 30_000 });

    const pdf = fs.readFileSync(tmpOut);
    return pdf;
  } finally {
    // Cleanup temp files regardless of success/failure
    [tmpIn, tmpOut].forEach(f => { try { fs.unlinkSync(f); } catch {} });
  }
}

module.exports = { generate };
