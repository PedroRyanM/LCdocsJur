'use strict';
const multer = require('multer');

const storage = multer.memoryStorage();

const logoUpload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith('image/')) return cb(null, true);
    cb(new Error('Apenas imagens são aceitas'));
  },
});

module.exports = { logoUpload };
