'use strict';

/**
 * SECOES — seções padrão do template.
 *
 * Seções customizadas são criadas dinamicamente no frontend
 * (via clausulas.store) e não precisam estar aqui — este arquivo
 * define apenas as seções predefinidas que chegam ao cliente.
 */
const SECOES = {
  PREAMBULO: {
    id:       'PREAMBULO',
    label:    'Preâmbulo',
    cor:      'muted',
    editavel: false,
    ponte:    null,
  },
  ALTERACAO: {
    id:       'ALTERACAO',
    label:    'Seção I — Alteração',
    cor:      'primary',
    editavel: true,
    ponte:    null,
  },
  CONTRATO: {
    id:       'CONTRATO',
    label:    'Seção II — Contrato Social',
    cor:      'success',
    editavel: true,
    ponte:    'Em face das alterações acima, transcrevo o contrato social, nos termos da Lei n° 10.406/2002, mediante as condições e cláusulas seguintes:',
  },
};

module.exports = { SECOES };
