'use strict';

const CLAUSULAS = {
  ABERTURA: {
    id: 'ABERTURA',
    label: 'Preâmbulo — Qualificação dos Sócios',
    secao: 'PREAMBULO',
    numerada: false,
    removivel: false,
    texto: '',
  },

  // ── SEÇÃO I ───────────────────────────────────────────────────
  TRANSFORMACAO: {
    id: 'TRANSFORMACAO',
    label: 'Transformação em LTDA',
    secao: 'ALTERACAO',
    numerada: true,
    removivel: true,
    texto: 'A sociedade que tem como nome empresarial: {{empresa_nome_atual}}, passará para: {{empresa_nome_novo}} e terá por nome de fantasia: {{empresa_fantasia}}.',
  },

  NOME_EMPRESARIAL_ALT: {
    id: 'NOME_EMPRESARIAL_ALT',
    label: 'Alteração de Nome',
    secao: 'ALTERACAO',
    numerada: true,
    removivel: true,
    texto: 'A sociedade que tem a denominação social: {{empresa_nome_atual}} passará para: {{empresa_nome_novo}} e terá por nome de fantasia: {{empresa_fantasia}}.',
  },

  ENTRADA_SOCIO: {
    id: 'ENTRADA_SOCIO',
    label: 'Entrada de Sócio(s)',
    secao: 'ALTERACAO',
    numerada: true,
    removivel: true,
    // Texto gerado dinamicamente pelo DocPreview baseado nos socios com papel='novo'
    texto: '__DINAMICO_ENTRADA_SOCIO__',
  },

  SAIDA_SOCIO: {
    id: 'SAIDA_SOCIO',
    label: 'Saída de Sócio(s)',
    secao: 'ALTERACAO',
    numerada: true,
    removivel: true,
    texto: '__DINAMICO_SAIDA_SOCIO__',
  },

  CAPITAL_SOCIAL_ALT: {
    id: 'CAPITAL_SOCIAL_ALT',
    label: 'Capital Social (com redistribuição)',
    secao: 'ALTERACAO',
    numerada: true,
    removivel: true,
    // Tabela de redistribuição gerada dinamicamente
    texto: '__DINAMICO_CAPITAL_ALT__',
  },

  FORO_ALTERACAO: {
    id: 'FORO_ALTERACAO',
    label: 'Foro da Alteração',
    secao: 'ALTERACAO',
    numerada: true,
    removivel: true,
    texto: 'Fica eleito o foro de {{foro}}, para o exercício e o cumprimento dos direitos e obrigações resultantes desta alteração.',
  },

  CLAUSULAS_INALTERADAS: {
    id: 'CLAUSULAS_INALTERADAS',
    label: 'Cláusulas Inalteradas',
    secao: 'ALTERACAO',
    numerada: true,
    removivel: true,
    texto: 'As demais cláusulas do contrato primitivo não serão modificadas por este instrumento, ficando, portanto, inalteradas.',
  },

  FILIAL: {
    id: 'FILIAL',
    label: 'Abertura de Filial',
    secao: 'ALTERACAO',
    numerada: true,
    removivel: true,
    texto: 'A sociedade resolve abrir uma filial que se localizará: {{filial_endereco}}. A filial terá como atividades sociais: {{filial_objeto}}.',
  },

  // ── SEÇÃO II — CONTRATO SOCIAL ────────────────────────────────
  MICRO_EMPRESA: {
    id: 'MICRO_EMPRESA',
    label: 'Enquadramento ME / EPP',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'Declara, sob as penas da lei, que se enquadra na condição de micro empresa ME, nos termos da Lei Complementar nº 123, de 14/10/2006.',
  },

  NOME_EMPRESARIAL: {
    id: 'NOME_EMPRESARIAL',
    label: 'Nome Empresarial',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'A sociedade gira sob o nome empresarial {{empresa_nome_novo}} e tem por nome de fantasia: {{empresa_fantasia}}.',
  },

  SEDE: {
    id: 'SEDE',
    label: 'Sede',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'A sociedade tem sua sede na {{sede_completa}}.',
  },

  CAPITAL_SOCIAL: {
    id: 'CAPITAL_SOCIAL',
    label: 'Capital Social',
    secao: 'CONTRATO',
    numerada: true,
    removivel: false,
    // Tabela de redistribuição gerada dinamicamente
    texto: '__DINAMICO_CAPITAL__',
  },

  OBJETO_SOCIAL: {
    id: 'OBJETO_SOCIAL',
    label: 'Objeto Social',
    secao: 'CONTRATO',
    numerada: true,
    removivel: false,
    texto: 'A sociedade tem por objeto: {{objeto_social}}.',
  },

  PRAZO: {
    id: 'PRAZO',
    label: 'Início e Prazo',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'A sociedade iniciou suas atividades em {{data_inicio}} e tem sua duração por tempo indeterminado.',
  },

  EXERCICIO_SOCIAL: {
    id: 'EXERCICIO_SOCIAL',
    label: 'Exercício Social e Lucros',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'Ao término de cada exercício social, em 31 de dezembro, o administrador prestará contas justificadas de sua administração, procedendo à elaboração do inventário, do balanço patrimonial e do balanço de resultado econômico, cabendo aos sócios, na proporção de suas quotas, os lucros ou perdas apuradas.\n\n§ 1º Por deliberação dos sócios a distribuição de lucros poderá ser em qualquer período do ano a partir de resultado do período apurado.\n\n§ 2º A distribuição dos lucros poderá não obedecer a participação do sócio desde que aprovada pelos sócios cotistas.',
  },

  DELIBERACOES: {
    id: 'DELIBERACOES',
    label: 'Deliberações dos Sócios',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'Nos quatro meses seguintes ao término do exercício social, os sócios deliberarão sobre as contas e designarão administrador(es), quando for o caso.',
  },

  ADMINISTRACAO: {
    id: 'ADMINISTRACAO',
    label: 'Administração',
    secao: 'CONTRATO',
    numerada: true,
    removivel: false,
    texto: 'A administração da sociedade cabe ISOLADAMENTE ao Sócio {{admins}}, com os poderes e atribuições de representação ativa e passiva na sociedade, judicial e extrajudicialmente, podendo praticar todos os atos compreendidos no objeto social, sempre de interesse da sociedade, autorizado o uso do nome empresarial, vedado, no entanto, fazê-lo em atividades estranhas ao interesse social ou assumir obrigações seja em favor de qualquer dos cotistas ou de terceiros, bem como onerar ou alienar bens imóveis da sociedade, sem autorização do(s) outro(s) sócio(s).\n\nParágrafo único: No exercício da administração, o administrador terá direito a uma retirada mensal a título de pró-labore, cujo valor será definido de comum acordo entre os sócios.',
  },

  IMPEDIMENTO: {
    id: 'IMPEDIMENTO',
    label: 'Impedimento do Administrador',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'O administrador declara, sob as penas da lei, que não está impedido de exercer a administração da sociedade, por lei especial ou em virtude de condenação criminal, ou por se encontrar sob os efeitos dela, a pena que vede, ainda que temporariamente, o acesso a cargos públicos, ou por crime falimentar, de prevaricação, peita ou suborno, concussão, peculato ou contra a economia popular, contra o sistema financeiro nacional, contra normas de defesa da concorrência, contra as relações de consumo, fé pública ou propriedade.',
  },

  SUCESSAO: {
    id: 'SUCESSAO',
    label: 'Falecimento / Sucessão',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'Falecendo ou interditado qualquer sócio, a sociedade continuará sua atividade com os herdeiros ou sucessores. Não sendo possível ou inexistindo interesse destes ou do(s) sócio(s) remanescente(s), o valor de seus haveres será apurado e liquidado com base na situação patrimonial da sociedade, à data da resolução, verificada em balanço especialmente levantado.\n\nParágrafo único: O mesmo procedimento será adotado em outros casos em que a sociedade se resolva em relação a seu sócio.',
  },

  CASOS_OMISSOS: {
    id: 'CASOS_OMISSOS',
    label: 'Casos Omissos',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'Os casos omissos no presente contrato serão resolvidos pelo consenso dos sócios, com observância da Lei nº 10.406/2002.',
  },

  FORO_CONTRATO: {
    id: 'FORO_CONTRATO',
    label: 'Foro do Contrato Social',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'Fica eleito o foro de {{foro}}, para o exercício e o cumprimento dos direitos e obrigações resultantes desta alteração.',
  },

  CLAUSULA_LIVRE: {
    id: 'CLAUSULA_LIVRE',
    label: 'Cláusula Personalizada',
    secao: 'CONTRATO',
    numerada: true,
    removivel: true,
    texto: 'Insira aqui o texto da cláusula personalizada.',
  },
};

const DEFAULT_ORDER = [
  'ABERTURA',
  'MICRO_EMPRESA', 'NOME_EMPRESARIAL', 'SEDE', 'CAPITAL_SOCIAL',
  'OBJETO_SOCIAL', 'PRAZO', 'EXERCICIO_SOCIAL', 'DELIBERACOES',
  'ADMINISTRACAO', 'IMPEDIMENTO', 'SUCESSAO', 'CASOS_OMISSOS', 'FORO_CONTRATO',
];

module.exports = { CLAUSULAS, DEFAULT_ORDER };
