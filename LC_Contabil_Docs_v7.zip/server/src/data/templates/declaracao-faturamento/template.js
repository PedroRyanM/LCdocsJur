'use strict';

/**
 * Template: Declaração de Faturamento
 * Baseado no documento DEMONSTRATIVO DE PREVISÃO DE FATURAMENTO
 */

const MESES_PT = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro',
];

module.exports = { MESES_PT };
