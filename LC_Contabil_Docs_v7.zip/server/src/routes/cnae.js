'use strict';
const { Router } = require('express');
const ctrl = require('../controllers/cnae.controller');

const router = Router();

router.get('/search', ctrl.search);   // ?q=ferragens&limit=30
router.get('/',       ctrl.listAll);

module.exports = router;
