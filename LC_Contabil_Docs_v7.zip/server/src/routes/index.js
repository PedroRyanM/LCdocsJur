'use strict';
const { Router } = require('express');

const router = Router();

router.use('/clausulas',   require('./clausulas'));
router.use('/cnae',        require('./cnae'));
router.use('/export',      require('./export'));
router.use('/upload',      require('./upload'));
router.use('/faturamento', require('./faturamento'));

router.get('/health', (_req, res) => res.json({ status: 'ok', ts: Date.now() }));

module.exports = router;
