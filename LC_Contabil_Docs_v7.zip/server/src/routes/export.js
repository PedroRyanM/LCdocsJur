'use strict';
const { Router } = require('express');
const ctrl = require('../controllers/export.controller');

const router = Router();

router.post('/docx', ctrl.exportDocx);
router.post('/pdf',  ctrl.exportPdf);

module.exports = router;
