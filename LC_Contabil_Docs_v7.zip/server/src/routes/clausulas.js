'use strict';
const { Router } = require('express');
const ctrl = require('../controllers/clausulas.controller');

const router = Router();

router.get('/', ctrl.list);

module.exports = router;
