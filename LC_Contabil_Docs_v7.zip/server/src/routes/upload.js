'use strict';
const { Router } = require('express');
const { logoUpload } = require('../middleware/multer');
const ctrl = require('../controllers/upload.controller');

const router = Router();

router.post('/logo', logoUpload.single('logo'), ctrl.uploadLogo);

module.exports = router;
