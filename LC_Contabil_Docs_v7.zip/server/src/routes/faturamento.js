'use strict';
const { Router } = require('express');
const ctrl = require('../controllers/faturamento.controller');

const router = Router();
router.get('/',         ctrl.getMeta);
router.post('/export',  ctrl.exportDocx);

module.exports = router;
