'use strict';
const express = require('express');
const cors    = require('cors');
const path    = require('path');
const cfg     = require('./config');
const routes  = require('./routes');
const { errorHandler } = require('./middleware/error');

const APP_NAME = 'LC Contábil Docs';

const app = express();

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true }));

// ── API routes ────────────────────────────────────────────────────────────────
app.use('/api', routes);

// ── Static client (production) ────────────────────────────────────────────────
if (cfg.isProd) {
  app.use(express.static(cfg.paths.clientBuild));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(cfg.paths.clientBuild, 'index.html'));
  });
}

// ── Error handler ─────────────────────────────────────────────────────────────
app.use(errorHandler);

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(cfg.port, () => {
  const url = `http://localhost:${cfg.port}`;
  console.log(`\n╔══════════════════════════════════════════╗`);
  console.log(`║  ${APP_NAME}  —  porta ${cfg.port}         ║`);
  console.log(`║  ${url.padEnd(40)}  ║`);
  console.log(`╚══════════════════════════════════════════╝\n`);

  if (cfg.isProd) {
    const { exec } = require('child_process');
    const open = process.platform === 'win32'
      ? `start ${url}`
      : process.platform === 'darwin' ? `open ${url}` : `xdg-open ${url}`;
    exec(open);
  }
});

module.exports = app;
