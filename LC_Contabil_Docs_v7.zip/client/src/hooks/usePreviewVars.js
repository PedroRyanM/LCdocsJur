import { useDocumentoStore } from '@/store/documento.store';
import { useSociosStore }    from '@/store/socios.store';

/**
 * Computes the full variables map used by both the live preview
 * and the export payload. Single source of truth.
 */
export function usePreviewVars() {
  const doc    = useDocumentoStore();
  const socios = useSociosStore(s => s.socios);

  const sede = [
    doc.sede_endereco,
    doc.sede_bairro,
    doc.sede_cidade,
    doc.sede_uf,
    doc.sede_cep ? `CEP ${doc.sede_cep}` : '',
  ].filter(Boolean).join(', ');

  const admins = socios
    .filter(s => s.admin === 'sim')
    .map(s => s.nome)
    .filter(Boolean)
    .join(', ');

  return {
    empresa_nome_atual: doc.empresa_nome_atual,
    empresa_nome_novo:  doc.empresa_nome_novo,
    empresa_fantasia:   doc.empresa_fantasia,
    empresa_cnpj:       doc.empresa_cnpj,
    empresa_nire:       doc.empresa_nire,
    sede_completa:      sede,
    cap_quotas:         doc.cap_quotas,
    cap_valor_quota:    doc.cap_valor_quota,
    cap_total:          doc.cap_total,
    objeto_social:      doc.objeto_social,
    data_inicio:        doc.data_inicio,
    data_assinatura:    doc.data_assinatura,
    cidade_assinatura:  doc.cidade_assinatura,
    foro:               doc.foro,
    admins,
    socios,
  };
}
