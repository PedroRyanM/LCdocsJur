import { useState } from 'react';
import { useDocTypeStore }        from '@/store/docType.store';
import { useDocumentoStore }      from '@/store/documento.store';
import { useSociosStore }         from '@/store/socios.store';
import { useClausulasStore }      from '@/store/clausulas.store';
import { useFaturamentoStore }    from '@/store/faturamento.store';
import { useUiStore }             from '@/store/ui.store';
import { usePreviewVars }         from './usePreviewVars';
import { exportDocx, exportFaturamentoDocx, downloadBlob } from '@/services/api';
import { generatePdf }            from '@/services/pdfEngine';

export function useExport() {
  const [loading, setLoading] = useState(null);
  const { docType }     = useDocTypeStore();
  const { showToast }   = useUiStore();
  const { logos }       = useDocumentoStore();
  const socios          = useSociosStore(s => s.socios);
  const { order, texts }= useClausulasStore();
  const vars            = usePreviewVars();
  const faturamento     = useFaturamentoStore();

  // ── DOCX export ─────────────────────────────────────────────
  async function handleExportDocx() {
    setLoading('docx');
    try {
      let blob;
      if (docType === 'faturamento') {
        blob = await exportFaturamentoDocx({
          empresa_nome:       faturamento.empresa_nome,
          empresa_endereco:   faturamento.empresa_endereco,
          empresa_cidade:     faturamento.empresa_cidade,
          empresa_cnpj:       faturamento.empresa_cnpj,
          socio_nome:         faturamento.socio_nome,
          meses:              faturamento.meses,
          assinatura_socio:   faturamento.assinatura_socio,
          assinatura_contador:faturamento.assinatura_contador,
          contador_crc:       faturamento.contador_crc,
          cidade_assinatura:  faturamento.cidade_assinatura,
          data_assinatura:    faturamento.data_assinatura,
        });
        downloadBlob(blob, 'declaracao_faturamento.docx');
      } else {
        blob = await exportDocx({
          data: { ...vars, socios },
          clausulaOrder: order,
          clausulaTexts: texts,
          logos,
        });
        downloadBlob(blob, 'alteracao_contratual.docx');
      }
      showToast('DOCX exportado com sucesso!', 'success');
    } catch (e) {
      showToast(`Erro ao gerar DOCX: ${e.message}`, 'error');
    } finally {
      setLoading(null);
    }
  }

  // ── PDF export (client-side, captures #doc-preview) ─────────
  async function handleExportPdf() {
    setLoading('pdf');
    try {
      const empresa = docType === 'faturamento'
        ? (faturamento.empresa_nome || 'declaracao').replace(/[^a-zA-Z0-9]/g, '_').slice(0, 40)
        : (vars.empresa_nome_atual  || 'documento').replace(/[^a-zA-Z0-9]/g, '_').slice(0, 40);
      await generatePdf(`${empresa}.pdf`);
      showToast('PDF gerado com sucesso!', 'success');
    } catch (e) {
      showToast(`Erro ao gerar PDF: ${e.message}`, 'error');
    } finally {
      setLoading(null);
    }
  }

  return { loading, handleExportDocx, handleExportPdf };
}
