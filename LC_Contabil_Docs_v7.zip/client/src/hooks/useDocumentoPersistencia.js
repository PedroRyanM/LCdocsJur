import { useCallback, useRef } from 'react';
import { useDocumentoStore }  from '@/store/documento.store';
import { useSociosStore }     from '@/store/socios.store';
import { useClausulasStore }  from '@/store/clausulas.store';
import { useRecentesStore, buildSnapshot } from '@/store/recentes.store';
import { useUiStore }         from '@/store/ui.store';

export function useDocumentoPersistencia() {
  const doc          = useDocumentoStore();
  const { socios }   = useSociosStore();
  const { order, texts, defaultOrder } = useClausulasStore();
  const { salvarDocumento, removerDocumento } = useRecentesStore();
  const { showToast } = useUiStore();

  // Track current doc ID (null = not yet saved)
  const currentIdRef = useRef(null);

  const salvar = useCallback((forceNew = false) => {
    // Collect current doc state (strip functions from zustand store)
    const docData = {
      titulo_documento:  doc.titulo_documento,
      natureza_processo: doc.natureza_processo,
      empresa_nome_atual:doc.empresa_nome_atual,
      empresa_nome_novo: doc.empresa_nome_novo,
      empresa_fantasia:  doc.empresa_fantasia,
      empresa_cnpj:      doc.empresa_cnpj,
      empresa_nire:      doc.empresa_nire,
      sede_endereco:     doc.sede_endereco,
      sede_bairro:       doc.sede_bairro,
      sede_cep:          doc.sede_cep,
      sede_cidade:       doc.sede_cidade,
      sede_uf:           doc.sede_uf,
      cap_quotas:        doc.cap_quotas,
      cap_valor_quota:   doc.cap_valor_quota,
      cap_total:         doc.cap_total,
      objeto_social:     doc.objeto_social,
      cnae_list:         doc.cnae_list,
      preambulo_custom:  doc.preambulo_custom,
      preambulo_fecho_custom: doc.preambulo_fecho_custom,
      data_inicio:       doc.data_inicio,
      data_assinatura:   doc.data_assinatura,
      cidade_assinatura: doc.cidade_assinatura,
      foro:              doc.foro,
    };

    const snapshot = buildSnapshot({
      doc:           docData,
      socios,
      clausulaOrder: order,
      clausulaTexts: texts,
      id:            forceNew ? null : currentIdRef.current,
    });

    const id = salvarDocumento(snapshot);
    currentIdRef.current = id;
    showToast('Documento salvo!', 'success');
    return id;
  }, [doc, socios, order, texts, salvarDocumento, showToast]);

  const restaurar = useCallback((snapshot) => {
    // Restore documento store
    const setField = doc.setField;
    Object.entries(snapshot.doc || {}).forEach(([k, v]) => {
      if (k !== 'logos') setField(k, v);
    });

    // Restore socios
    const { socios: storeSocios, addSocio, removeSocio } = useSociosStore.getState();
    // Clear existing socios and re-add from snapshot
    storeSocios.forEach(s => removeSocio(s.id));
    (snapshot.socios || []).forEach(s => addSocio(s));

    // Restore clausulas
    const { defaultOrder: defOrder } = useClausulasStore.getState();
    useClausulasStore.setState({
      order: snapshot.clausulaOrder || defOrder,
      texts: snapshot.clausulaTexts || {},
    });

    currentIdRef.current = snapshot.id;
    showToast(`"${snapshot.titulo}" restaurado`, 'success');
  }, [doc.setField, showToast]);

  return { salvar, restaurar, removerDocumento, currentId: currentIdRef.current };
}
