import React from 'react';
import { useModificacoesStore, MODIFICACOES_CONFIG } from '@/store/modificacoes.store';
import { SectionHeader } from '@/components/ui/SectionHeader';
import styles from './ModificacoesSection.module.css';

export function ModificacoesSection() {
  const { selecionadas, toggle, clearAll, setAll } = useModificacoesStore();

  const totalSel = selecionadas.size;

  return (
    <div>
      <SectionHeader>Modificações do Documento</SectionHeader>
      <p className="help-text">
        Marque as modificações que este documento contempla. As cláusulas
        correspondentes serão adicionadas e ordenadas automaticamente.
      </p>

      <div className={styles.actions}>
        <button className={styles.actionLink} onClick={() =>
          setAll(MODIFICACOES_CONFIG.map(m => m.id))
        }>Marcar todas</button>
        <span className={styles.actionSep}>·</span>
        <button className={styles.actionLink} onClick={clearAll}>Limpar</button>
        {totalSel > 0 && (
          <>
            <span className={styles.actionSep}>·</span>
            <span className={styles.actionCount}>{totalSel} selecionada{totalSel > 1 ? 's' : ''}</span>
          </>
        )}
      </div>

      <div className={styles.grid}>
        {MODIFICACOES_CONFIG.map(mod => {
          const active = selecionadas.has(mod.id);
          return (
            <button
              key={mod.id}
              className={`${styles.card} ${active ? styles.cardActive : ''}`}
              onClick={() => toggle(mod.id)}
              type="button"
            >
              <div className={styles.cardTop}>
                <span className={styles.cardIcon}>{mod.icon}</span>
                <span className={`${styles.checkbox} ${active ? styles.checkboxActive : ''}`}>
                  {active ? '✓' : ''}
                </span>
              </div>
              <div className={styles.cardLabel}>{mod.label}</div>
              <div className={styles.cardDesc}>{mod.desc}</div>
            </button>
          );
        })}
      </div>

      {totalSel === 0 && (
        <div className={styles.emptyState}>
          <span>☝</span>
          <p>Selecione pelo menos uma modificação para o documento.</p>
        </div>
      )}
    </div>
  );
}
