import React, { useRef } from 'react';
import { useDocumentoStore } from '@/store/documento.store';
import { useUiStore }        from '@/store/ui.store';
import { uploadLogo }        from '@/services/api';
import { SectionHeader }     from '@/components/ui/SectionHeader';
import { Button }            from '@/components/ui/Button';
import styles from './LogosSection.module.css';

function LogoSlot({ slot, label, icon }) {
  const { logos, setLogo, clearLogo } = useDocumentoStore();
  const { showToast } = useUiStore();
  const fileRef = useRef();

  const logo = logos[slot];

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const data = await uploadLogo(file);
      setLogo(slot, data);
      showToast(`Logo "${label}" carregada!`, 'success');
    } catch {
      showToast('Erro ao carregar imagem', 'error');
    }
    e.target.value = '';
  }

  return (
    <div className={styles.slot}>
      <div className={styles.slotLabel}>{label}</div>

      <button
        className={`${styles.dropZone} ${logo ? styles.hasLogo : ''}`}
        onClick={() => fileRef.current?.click()}
        title="Clique para selecionar imagem"
      >
        {logo ? (
          <img
            src={`data:${logo.mimetype};base64,${logo.base64}`}
            alt={label}
            className={styles.logoPreview}
          />
        ) : (
          <div className={styles.empty}>
            <span className={styles.emptyIcon}>{icon}</span>
            <span className={styles.emptyHint}>Clique para carregar</span>
            <span className={styles.emptyFormats}>PNG, JPG, SVG — até 5 MB</span>
          </div>
        )}
      </button>

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        style={{ display: 'none' }}
        onChange={handleFile}
      />

      <div className={styles.slotActions}>
        <Button variant="secondary" size="sm" onClick={() => fileRef.current?.click()}>
          {logo ? '↺ Trocar' : '+ Carregar'}
        </Button>
        {logo && (
          <Button variant="danger" size="sm" onClick={() => clearLogo(slot)}>
            ✕ Remover
          </Button>
        )}
      </div>
    </div>
  );
}

export function LogosSection() {
  return (
    <div>
      <SectionHeader>Logomarcas do Documento</SectionHeader>
      <p className="help-text">
        As logos aparecem no topo do documento exportado — cliente à esquerda,
        contabilidade à direita. A logo do aplicativo é configurada no cabeçalho.
      </p>

      <div className={styles.grid}>
        <LogoSlot slot="client" label="Logo do Cliente"        icon="🏢" />
        <LogoSlot slot="contab" label="Logo da Contabilidade"  icon="📊" />
      </div>

      <div className={styles.note}>
        <strong>Dica:</strong> use imagens com fundo transparente (PNG ou SVG) para
        melhor resultado no documento.
      </div>
    </div>
  );
}
