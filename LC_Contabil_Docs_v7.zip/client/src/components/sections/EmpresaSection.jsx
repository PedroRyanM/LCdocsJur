import React, { useState } from 'react';
import { useDocumentoStore } from '@/store/documento.store';
import { Field, Input }      from '@/components/ui/Field';
import { SectionHeader }     from '@/components/ui/SectionHeader';
import styles from './EmpresaSection.module.css';

// Títulos predefinidos — clique aplica direto
const TITULOS_PRESET = [
  'ALTERAÇÃO DO CONTRATO SOCIAL DE',
  'TRANSFORMAÇÃO EMPRESARIAL DE',
  'INCLUSÃO DE SÓCIO —',
  'RETIRADA DE SÓCIO —',
  'ALTERAÇÃO DE CAPITAL SOCIAL DE',
  'ALTERAÇÃO DE OBJETO SOCIAL DE',
  'ALTERAÇÃO DE SEDE DE',
  'ALTERAÇÃO DE ADMINISTRAÇÃO DE',
  'DISSOLUÇÃO E LIQUIDAÇÃO DE',
];

export function EmpresaSection() {
  const { setField, ...doc } = useDocumentoStore();
  const [showPresets, setShowPresets] = useState(false);

  const f = (key) => ({
    value:    doc[key] ?? '',
    onChange: (e) => setField(key, e.target.value),
  });

  function applyPreset(titulo) {
    setField('titulo_documento', titulo);
    setShowPresets(false);
  }

  return (
    <div>
      <SectionHeader>Documento</SectionHeader>

      {/* Título unificado com presets */}
      <div className={styles.tituloWrapper}>
        <label className={styles.tituloLabel}>Título do Documento</label>
        <div className={styles.tituloInputRow}>
          <Input
            placeholder="ALTERAÇÃO DO CONTRATO SOCIAL DE"
            value={doc.titulo_documento ?? ''}
            onChange={e => setField('titulo_documento', e.target.value)}
            className={styles.tituloInput}
          />
          <button
            className={styles.presetToggle}
            onClick={() => setShowPresets(v => !v)}
            title="Predefinições"
            type="button"
          >
            {showPresets ? '▲' : '▼'} Modelos
          </button>
        </div>

        {showPresets && (
          <div className={styles.presetList}>
            {TITULOS_PRESET.map(t => (
              <button
                key={t}
                className={`${styles.presetItem} ${doc.titulo_documento === t ? styles.presetActive : ''}`}
                onClick={() => applyPreset(t)}
                type="button"
              >
                {t}
              </button>
            ))}
          </div>
        )}
      </div>

      <SectionHeader>Identificação</SectionHeader>

      <Field label="Nome Empresarial (atual)">
        <Input placeholder="UNIFORTES ABRASIVOS LTDA" {...f('empresa_nome_atual')} />
      </Field>
      <Field label="CNPJ">
        <Input placeholder="42.535.396/0001-11" {...f('empresa_cnpj')} />
      </Field>
      <Field label="NIRE">
        <Input placeholder="52807667954" {...f('empresa_nire')} />
      </Field>

      <div className="field-row">
        <Field label="Nome Empresarial (novo)">
          <Input placeholder="UNIFORT ABRASIVOS LTDA" {...f('empresa_nome_novo')} />
        </Field>
        <Field label="Nome Fantasia">
          <Input placeholder="UNIFORT ABRASIVOS" {...f('empresa_fantasia')} />
        </Field>
      </div>

      <SectionHeader>Sede</SectionHeader>

      <Field label="Endereço">
        <Input placeholder="RUA GENTIL PINTO, Nº 1.150, QD. 82, LT. 09" {...f('sede_endereco')} />
      </Field>
      <div className="field-row">
        <Field label="Bairro">
          <Input placeholder="Vila Rosa" {...f('sede_bairro')} />
        </Field>
        <Field label="CEP">
          <Input placeholder="74.345-230" {...f('sede_cep')} />
        </Field>
      </div>
      <div className="field-row">
        <Field label="Cidade">
          <Input placeholder="Goiânia" {...f('sede_cidade')} />
        </Field>
        <Field label="UF">
          <Input placeholder="GO" maxLength={2} {...f('sede_uf')} />
        </Field>
      </div>

      <SectionHeader>Capital Social</SectionHeader>

      <div className="field-row">
        <Field label="Total de Quotas">
          <Input placeholder="60.000" {...f('cap_quotas')} />
        </Field>
        <Field label="Valor / Quota (R$)">
          <Input placeholder="1,00" {...f('cap_valor_quota')} />
        </Field>
      </div>
      <Field label="Valor Total (R$)">
        <Input placeholder="60.000,00" {...f('cap_total')} />
      </Field>

      <SectionHeader>Datas e Foro</SectionHeader>

      <div className="field-row">
        <Field label="Início das Atividades">
          <Input placeholder="30/06/2021" {...f('data_inicio')} />
        </Field>
        <Field label="Data da Assinatura">
          <Input placeholder="04 de abril de 2025" {...f('data_assinatura')} />
        </Field>
      </div>
      <div className="field-row">
        <Field label="Cidade da Assinatura">
          <Input placeholder="Goiânia-GO" {...f('cidade_assinatura')} />
        </Field>
        <Field label="Foro Eleito">
          <Input placeholder="Goiânia, capital do estado de Goiás" {...f('foro')} />
        </Field>
      </div>
    </div>
  );
}
