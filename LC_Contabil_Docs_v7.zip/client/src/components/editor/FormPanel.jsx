import React from 'react';
import { useUiStore }      from '@/store/ui.store';
import { useDocTypeStore } from '@/store/docType.store';

import { EmpresaSection }      from '@/components/sections/EmpresaSection';
import { ModificacoesSection } from '@/components/sections/ModificacoesSection';
import { SociosSection }       from '@/components/socios/SociosSection';
import { ClausulasSection }    from '@/components/clausulas/ClausulasSection';
import { CNAESection }         from '@/components/cnae/CNAESection';
import { LogosSection }        from '@/components/sections/LogosSection';
import { FaturamentoSection }  from '@/components/faturamento/FaturamentoSection';

import styles from './FormPanel.module.css';

const ALTERACAO_SECTIONS = {
  empresa:      <EmpresaSection />,
  modificacoes: <ModificacoesSection />,
  socios:       <SociosSection />,
  clausulas:    <ClausulasSection />,
  cnae:         <CNAESection />,
  logos:        <LogosSection />,
};

export function FormPanel() {
  const { activeSection } = useUiStore();
  const { docType }       = useDocTypeStore();

  const content = docType === 'faturamento'
    ? <FaturamentoSection />
    : (ALTERACAO_SECTIONS[activeSection] ?? null);

  return (
    <aside className={styles.panel}>
      <div className={styles.body}>
        {content}
      </div>
    </aside>
  );
}
