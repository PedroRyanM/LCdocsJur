import React from 'react';
import { useDocTypeStore } from '@/store/docType.store';
import { DocPreview }         from './DocPreview';
import { FaturamentoPreview } from '@/components/faturamento/FaturamentoPreview';
import styles from './PreviewPanel.module.css';

export function PreviewPanel({ onExportDocx, onExportPdf, exportLoading }) {
  const { docType } = useDocTypeStore();

  return (
    <div className={styles.panel}>
      <div className={styles.toolbar}>
        <div className={styles.toolbarLeft}>
          <span className={styles.label}>Prévia do Documento</span>
          <span className={styles.live}>
            <span className={styles.liveDot} />
            Tempo real
          </span>
        </div>
        <div className={styles.toolbarRight}>
          <button className={styles.exportBtn} onClick={onExportDocx}
            disabled={exportLoading === 'docx'}>
            {exportLoading === 'docx' ? '…' : '⬇'} DOCX
          </button>
          <button className={styles.exportBtn} onClick={onExportPdf}
            disabled={exportLoading === 'pdf'}>
            {exportLoading === 'pdf' ? '…' : '⬇'} PDF
          </button>
        </div>
      </div>

      <div className={styles.content}>
        {docType === 'faturamento' ? <FaturamentoPreview /> : <DocPreview />}
      </div>
    </div>
  );
}
