import React, { useMemo } from 'react';
import { useClausulasStore }    from '@/store/clausulas.store';
import { useModificacoesStore } from '@/store/modificacoes.store';
import { useDocumentoStore }    from '@/store/documento.store';
import { useSociosStore }       from '@/store/socios.store';
import { usePreviewVars }       from '@/hooks/usePreviewVars';
import { ordinal }              from '@/constants/ordinals';
import styles from './DocPreview.module.css';

// ── Helpers ───────────────────────────────────────────────────────────────────
function resolveText(text, vars) {
  return text.replace(/\{\{(\w+)\}\}/g, (_, k) =>
    vars[k] ? `<span class="var-filled">${vars[k]}</span>`
            : `<span class="var-empty">[${k}]</span>`
  );
}
function fv(val, label) {
  return val
    ? `<span class="var-filled">${val}</span>`
    : `<span class="var-empty">[${label}]</span>`;
}
function qualificar(s) {
  return [
    s.nome ? `<strong>${s.nome.toUpperCase()}</strong>` : `<span class="var-empty">[NOME]</span>`,
    s.nacionalidade ? `, ${s.nacionalidade.toLowerCase()}` : '',
    s.estado_civil  ? `, ${s.estado_civil}` : '',
    s.regime        ? ` pelo regime de ${s.regime}` : '',
    s.profissao     ? `, ${s.profissao}` : '',
    s.nascimento    ? `, nascido em ${s.nascimento}` : '',
    s.cpf           ? `, portador do CPF ${s.cpf}` : '',
    s.rg            ? ` e do RG ${s.rg}` : '',
    s.endereco      ? `, residente e domiciliado na ${s.endereco}` : '',
  ].join('');
}
function parseQts(v) {
  return parseFloat(String(v||0).replace(/\./g,'').replace(',','.')) || 0;
}
function fmtNum(n) { return n.toLocaleString('pt-BR'); }
function fmtPct(n) { return n.toFixed(2).replace('.',',') + '%'; }

// ── Capital redistribution table HTML ─────────────────────────────────────────
function redistribTableHTML(ativos, s) {
  const totalQts = ativos.reduce((a,x)=>a+parseQts(x.quotas),0);
  const totalVal = ativos.reduce((a,x)=>a+parseQts(x.quotas_valor),0);
  const rows = ativos.map((x,i) => {
    const qts = parseQts(x.quotas);
    const val = parseQts(x.quotas_valor);
    const pct = totalQts > 0 ? (qts/totalQts)*100 : 0;
    return `<tr class="${i%2?s.trAlt:''}">
      <td class="${s.td} ${s.tdNome}"><strong>${x.nome||'—'}</strong></td>
      <td class="${s.td} ${s.tdNum}">${fmtNum(qts)}</td>
      <td class="${s.td} ${s.tdNum}">R$ ${fmtNum(val)}</td>
      <td class="${s.td} ${s.tdPct}">${fmtPct(pct)}</td>
    </tr>`;
  }).join('');
  return `
    <table class="${s.redistribTable}">
      <thead><tr class="${s.thead}">
        <th class="${s.th}">Nome do Sócio</th>
        <th class="${s.th} ${s.thNum}">Qtd Quotas</th>
        <th class="${s.th} ${s.thNum}">Valor (R$)</th>
        <th class="${s.th} ${s.thPct}">%</th>
      </tr></thead>
      <tbody>${rows}
        <tr class="${s.tfoot}">
          <td class="${s.tdTotal}">TOTAL:</td>
          <td class="${s.tdTotal} ${s.tdNum}">${fmtNum(totalQts)}</td>
          <td class="${s.tdTotal} ${s.tdNum}">R$ ${fmtNum(totalVal)}</td>
          <td class="${s.tdTotal} ${s.tdPct}">100%</td>
        </tr>
      </tbody>
    </table>`;
}

function renderCnaeTable(cnaeList, s) {
  if (!cnaeList?.length) return '';
  const obj = cnaeList.map(c=>c.denominacao.toUpperCase()).join(', ');
  const rows = cnaeList.map(c =>
    `<tr><td class="${s.cnaeCode}">${c.codigo}</td><td class="${s.cnaeDesc}">${c.denominacao}</td></tr>`
  ).join('');
  return `<span class="var-filled">${obj}</span>
    <br><br><div class="${s.cnaeBlock}">
      <div class="${s.cnaeTitle}">CODIFICAÇÃO DAS ATIVIDADES ECONÔMICAS</div>
      <table class="${s.cnaeTable}"><tbody>${rows}</tbody></table>
    </div>`;
}

// ── Main hook ─────────────────────────────────────────────────────────────────
function useDocHTML() {
  const { order, definitions, texts, getOrdinals, getAllSecoes, getClausulaLabel } = useClausulasStore();
  const { getClausulasOrdem } = useModificacoesStore();
  const { logos, titulo_documento, natureza_processo, cnae_list,
          preambulo_custom, preambulo_fecho_custom, cap_quotas, cap_valor_quota, cap_total } = useDocumentoStore();
  const vars   = usePreviewVars();
  const socios = useSociosStore(s => s.socios);

  const vigentes   = socios.filter(s => s.papel === 'vigente');
  const novos      = socios.filter(s => s.papel === 'novo');
  const retirantes = socios.filter(s => s.papel === 'retirante');
  const ativos     = socios.filter(s => s.papel !== 'retirante');
  const allSecoes  = getAllSecoes();

  // Merge clause order: from modificações (Seção I) + manual order (Seção II)
  const modClausulas = getClausulasOrdem(); // dynamic from checkboxes
  const manualOrder  = order;              // manual manager order

  // Build unified order: ABERTURA + mod clauses + manual clauses (dedup)
  const seen = new Set(['ABERTURA', ...modClausulas]);
  const unifiedOrder = [
    'ABERTURA',
    ...modClausulas,
    ...manualOrder.filter(id => !seen.has(id) && definitions[id]?.secao !== 'ALTERACAO'),
  ];

  return useMemo(() => {
    let html = '';
    const ordinals = getOrdinals();
    const counters = {};
    let   prevSecao = null;

    // Logos
    if (logos.client || logos.contab) {
      html += `<div class="${styles.logoHeader}">`;
      html += logos.client ? `<img src="data:${logos.client.mimetype};base64,${logos.client.base64}" alt="Logo">` : '<div></div>';
      html += logos.contab ? `<img src="data:${logos.contab.mimetype};base64,${logos.contab.base64}" alt="Logo">` : '<div></div>';
      html += '</div>';
    }

    // Title
    const titulo = titulo_documento || 'ALTERAÇÃO DO CONTRATO SOCIAL DE';
    html += `<div class="${styles.docTitle}">${titulo}</div>`;
    if (natureza_processo) html += `<div class="${styles.docNatureza}">${natureza_processo}</div>`;
    html += `<div class="${styles.docSubtitle}">${fv(vars.empresa_nome_atual?.toUpperCase(),'NOME DA EMPRESA')}</div>`;
    html += `<div class="${styles.docCnpj}">${fv(vars.empresa_cnpj,'CNPJ')}</div>`;

    // ── Render each clause ───────────────────────────────────────
    for (let i = 0; i < unifiedOrder.length; i++) {
      const clausulaId = unifiedOrder[i];
      const def        = definitions[clausulaId];
      if (!def) continue;

      // Section bridge
      if (def.secao !== prevSecao) {
        const sec = allSecoes[def.secao];
        if (sec?.ponte && def.secao !== 'PREAMBULO') {
          html += `<p class="${styles.sectionBridge}">${sec.ponte}</p>`;
        }
        if (sec?.custom) html += `<div class="${styles.sectionHeading}">${sec.label}</div>`;
        prevSecao = def.secao;
      }

      // ── ABERTURA ─────────────────────────────────────────────
      if (clausulaId === 'ABERTURA') {
        const noPreambulo = [...vigentes, ...retirantes];
        if (!noPreambulo.length && !novos.length) {
          html += `<p>${fv('','Qualificação dos sócios — adicione sócios na aba Sócios')}</p>`;
        } else {
          noPreambulo.forEach(s => { html += `<p>${qualificar(s)}, BRASIL.</p>`; });
          const nomes = noPreambulo.map(s=>s.nome||'[SÓCIO]').join(', ');
          const fecho = preambulo_fecho_custom
            ? resolveText(preambulo_fecho_custom, vars)
            : `${nomes}, sócio${noPreambulo.length>1?'s':''} da empresa: <strong>${fv(vars.empresa_nome_atual,'EMPRESA')}</strong>, com sede na ${fv(vars.sede_completa,'SEDE')}, inscrita no CNPJ sob o nº ${fv(vars.empresa_cnpj,'CNPJ')}, resolve neste ato proceder à presente alteração contratual, nos termos da Lei n° 10.406/2002, mediante as condições estabelecidas nas cláusulas seguintes:`;
          html += `<p>${fecho}</p>`;
        }
        continue;
      }

      // ── Dynamic: ENTRADA DE SÓCIO ────────────────────────────
      if (clausulaId === 'ENTRADA_SOCIO') {
        if (!def.numerada) { continue; }
        counters[def.secao] = (counters[def.secao] || 0) + 1;
        const num   = counters[def.secao];
        const label = `<span class="clause-title">CLÁUSULA ${ordinal(num)}.</span> `;

        const cedente = vigentes[0];
        const nomeCedente = cedente?.nome ? cedente.nome.toUpperCase() : '[SÓCIO CEDENTE]';
        const qualNovos = novos.map(s => qualificar(s)).join(' e ');

        if (novos.length === 0) {
          html += `<p>${label}${fv('','Adicione sócios com papel "Entrante" na aba Sócios')}</p>`;
        } else {
          html += `<p>${label}O sócio <strong>${nomeCedente}</strong>, acima qualificado, cede e transfere parte de suas quotas do capital social ao${novos.length>1?'s':''} novo${novos.length>1?'s':''} sócio${novos.length>1?'s':''}: ${qualNovos}.</p>`;
          html += `<p>Com a admissão do${novos.length>1?'s':''} novo${novos.length>1?'s':''} sócio${novos.length>1?'s':''} <strong>${novos.map(s=>s.nome?.toUpperCase()||'[SÓCIO]').join(', ')}</strong>, o capital social da sociedade ficará assim distribuído:</p>`;
          html += redistribTableHTML(ativos, styles);
          html += `<p class="${styles.indent}"><strong>PARÁGRAFO PRIMEIRO</strong>: Nos termos do Art. 1.052 do código civil (Lei nº 10.406/2002) a responsabilidade de cada sócio é restrita ao valor de suas quotas, mas, todos respondem solidariamente pela integralização do capital social.</p>`;
          html += `<p class="${styles.indent}"><strong>PARÁGRAFO SEGUNDO</strong>: A nenhum sócio é permitido vender, ceder, transferir, bem como alienar sob qualquer título, parte ou totalidade das quotas de capital que possuir na sociedade, sem o expresso consentimento por escrito do outro sócio, o qual terá preferência em suas aquisições.</p>`;
        }
        continue;
      }

      // ── Dynamic: SAÍDA DE SÓCIO ──────────────────────────────
      if (clausulaId === 'SAIDA_SOCIO') {
        counters[def.secao] = (counters[def.secao] || 0) + 1;
        const num   = counters[def.secao];
        const label = `<span class="clause-title">CLÁUSULA ${ordinal(num)}.</span> `;

        if (retirantes.length === 0) {
          html += `<p>${label}${fv('','Adicione sócios com papel "Retirante" na aba Sócios')}</p>`;
        } else {
          const nomesRet = retirantes.map(s => `<strong>${s.nome?.toUpperCase()||'[SÓCIO]'}</strong>`).join(', ');
          html += `<p>${label}O${retirantes.length>1?'s':''} sócio${retirantes.length>1?'s':''} ${nomesRet} retira${retirantes.length>1?'m-se':'-se'} do quadro societário, cedendo a totalidade de suas quotas aos sócios remanescentes, aos quais dá plena e geral quitação das quotas ora transferidas.</p>`;
          html += `<p>Com a saída do${retirantes.length>1?'s':''} referido${retirantes.length>1?'s':''} sócio${retirantes.length>1?'s':''}, o capital social ficará assim distribuído:</p>`;
          html += redistribTableHTML(ativos, styles);
        }
        continue;
      }

      // ── Dynamic: CAPITAL_SOCIAL_ALT ──────────────────────────
      if (clausulaId === 'CAPITAL_SOCIAL_ALT') {
        counters[def.secao] = (counters[def.secao] || 0) + 1;
        const num   = counters[def.secao];
        const label = `<span class="clause-title">CLÁUSULA ${ordinal(num)}.</span> `;
        html += `<p>${label}O capital social da sociedade, que era de ${fv(vars.cap_total,'CAPITAL ANTERIOR')}, passa a ser de ${fv(vars.cap_quotas,'TOTAL DE QUOTAS')} quotas de valor unitário R$ ${fv(vars.cap_valor_quota,'VALOR/QUOTA')}, totalizando R$ ${fv(vars.cap_total,'TOTAL')}, integralizado em moeda corrente do país, assim distribuído:</p>`;
        html += redistribTableHTML(ativos, styles);
        html += `<p class="${styles.indent}"><strong>Parágrafo primeiro</strong>: A responsabilidade de cada sócio fica restrita ao valor de suas quotas, nos termos do Art. 1.052 do Código Civil.</p>`;
        continue;
      }

      // ── Dynamic: CAPITAL_SOCIAL (seção II) ───────────────────
      if (clausulaId === 'CAPITAL_SOCIAL') {
        counters[def.secao] = (counters[def.secao] || 0) + 1;
        const num   = counters[def.secao];
        const label = `<span class="clause-title">CLÁUSULA ${ordinal(num)}.</span> `;
        html += `<p>${label}O capital social da sociedade é de ${fv(vars.cap_quotas,'TOTAL DE QUOTAS')} quotas de valor unitário R$ ${fv(vars.cap_valor_quota,'VALOR/QUOTA')}, totalizando R$ ${fv(vars.cap_total,'TOTAL')}, totalmente subscrito e integralizado em moeda corrente do país, distribuído entre os sócios da seguinte forma:</p>`;
        html += redistribTableHTML(ativos, styles);
        html += `<p class="${styles.indent}"><strong>Parágrafo primeiro</strong>: A responsabilidade dos sócios, nos termos do artigo 1.052 da lei 10.406/2002, é limitada ao valor de suas quotas.</p>`;
        continue;
      }

      // ── Numbered clause (generic) ────────────────────────────
      if (def.numerada) {
        counters[def.secao] = (counters[def.secao] || 0) + 1;
        const num        = counters[def.secao];
        const clausTitle = `<span class="clause-title">CLÁUSULA ${ordinal(num)}.</span> `;
        const rawText    = texts[clausulaId] !== undefined ? texts[clausulaId] : def.texto;

        if (rawText.startsWith('__DINAMICO')) continue; // skip unhandled dynamic markers

        const resolved = resolveText(rawText, vars);
        const lines    = resolved.split('\n').filter(l => l.trim());

        if (clausulaId === 'OBJETO_SOCIAL' && cnae_list?.length > 0) {
          html += `<p>${clausTitle}A sociedade tem por objeto: ${renderCnaeTable(cnae_list, styles)}</p>`;
          continue;
        }

        lines.forEach((line, idx) => {
          if (idx === 0) html += `<p>${clausTitle}${line}</p>`;
          else if (/^[§Pp]/.test(line)) html += `<p class="${styles.indent}">${line}</p>`;
          else html += `<p>${line}</p>`;
        });
      }
    }

    // Date & signatures — all ativos sign
    html += `<div class="${styles.docDate}">${fv(vars.cidade_assinatura,'Cidade')}, ${fv(vars.data_assinatura,'Data')}.</div>`;
    html += '<div class="' + styles.signatureBlock + '">';
    const sigSocios = ativos.length ? ativos : [{ nome:'', admin:'sim', papel:'vigente' }];
    sigSocios.forEach(s => {
      const role = s.admin==='sim' ? 'Sócio e Administrador' : 'Sócio';
      const extra = s.papel === 'novo' ? ' (Ingressante)' : '';
      html += `<div class="${styles.signatureItem}">
        <hr class="${styles.signatureRule}">
        <div class="${styles.signatureName}">${s.nome||fv('','NOME')}</div>
        <div class="${styles.signatureRole}">${role}${extra}</div>
      </div>`;
    });
    html += '</div>';
    return html;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unifiedOrder, definitions, texts, vars, logos, socios, titulo_documento,
      natureza_processo, cnae_list, preambulo_fecho_custom, allSecoes]);
}

export function DocPreview() {
  const html = useDocHTML();
  return (
    <div id="doc-preview" className={styles.page}
      dangerouslySetInnerHTML={{ __html: html }} />
  );
}
