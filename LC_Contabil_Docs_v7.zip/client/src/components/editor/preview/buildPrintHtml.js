/**
 * buildPrintHtml
 * Captures the rendered preview DOM and wraps it in a complete,
 * self-contained HTML document ready for wkhtmltopdf.
 */
export function buildPrintHtml() {
  const previewEl = document.getElementById('doc-preview');
  if (!previewEl) throw new Error('Preview element not found');

  const body = previewEl.innerHTML;

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --rust:    #903010;
    --gold:    #C0B090;
    --green:   #2D6A4F;
    --muted:   #7A6050;
    --ink:     #2A1A10;
    --border:  #C0B090;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Times New Roman', serif;
    font-size:   11pt;
    color:       var(--ink);
    line-height: 1.75;
    background:  #fff;
    padding:     0;
  }
  .doc-title {
    font-family: 'Playfair Display', serif;
    font-size:   14pt;
    font-weight: 700;
    text-align:  center;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 3px;
  }
  .doc-subtitle {
    font-family: 'Playfair Display', serif;
    font-size:   13pt;
    font-weight: 700;
    text-align:  center;
    margin-bottom: 4px;
  }
  .doc-cnpj {
    font-family: 'DM Mono', monospace;
    font-size:   9pt;
    text-align:  center;
    margin-bottom: 20px;
    color:       var(--muted);
  }
  p {
    margin-bottom: 10px;
    text-align:    justify;
    hyphens:       auto;
  }
  .clause-title { font-weight: 700; }
  .section-bridge {
    margin:      16px 0 12px;
    font-style:  italic;
    border-left: 3px solid var(--green);
    padding-left:10px;
  }
  .var-filled {
    border-bottom: 2px solid var(--gold);
    font-weight:   500;
  }
  .var-empty {
    color:      #c0392b;
    font-style: italic;
    border-bottom: 1px dashed #c0392b;
  }
  .doc-date {
    text-align:  right;
    font-style:  italic;
    color:       var(--muted);
    margin-top:  24px;
  }
  .signature-block { margin-top: 40px; }
  .signature-item  { text-align: center; margin-top: 48px; }
  .signature-rule  {
    border:    none;
    border-top:1px solid #555;
    width:     220px;
    margin:    0 auto 5px;
  }
  .signature-name {
    font-weight:    700;
    font-size:      9pt;
    text-transform: uppercase;
  }
  .signature-role {
    font-size: 8.5pt;
    color:     var(--muted);
    margin-top:2px;
  }
  .logo-header {
    display:         flex;
    justify-content: space-between;
    align-items:     center;
    margin-bottom:   16px;
    padding-bottom:  10px;
    border-bottom:   1px solid var(--border);
  }
  .logo-header img {
    max-height: 48px;
    max-width:  150px;
    object-fit: contain;
  }
</style>
</head>
<body>${body}</body>
</html>`;
}
