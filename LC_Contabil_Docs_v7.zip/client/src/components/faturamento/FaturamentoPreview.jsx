import React, { useMemo } from 'react';
import { useFaturamentoStore } from '@/store/faturamento.store';
import styles from './FaturamentoPreview.module.css';

function fmt(val) {
  if (!val && val !== 0) return '—';
  const n = parseFloat(String(val).replace(/[^\d,.-]/g, '').replace(',', '.'));
  if (isNaN(n)) return val || '—';
  return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function fv(val, label) {
  if (val) return `<strong>${val}</strong>`;
  return `<span class="var-empty">[${label}]</span>`;
}

export function FaturamentoPreview() {
  const store = useFaturamentoStore();
  const total = store.getTotal();

  const html = useMemo(() => {
    const {
      empresa_nome, empresa_endereco, empresa_cidade, empresa_cnpj,
      meses, assinatura_socio, assinatura_contador, contador_crc,
      socio_nome, cidade_assinatura, data_assinatura, logo,
    } = store;

    let h = '';

    // Logo
    if (logo) {
      h += `<div class="${styles.logoHeader}">
        <img src="data:${logo.mimetype};base64,${logo.base64}" alt="Logo" class="${styles.logoImg}">
      </div>`;
    }

    // Title
    h += `<div class="${styles.title}">DEMONSTRATIVO DE PREVISÃO DE FATURAMENTO</div>`;

    // Company table
    h += `<table class="${styles.infoTable}">
      <tr>
        <td class="${styles.infoLabel}">Empresa:</td>
        <td class="${styles.infoValue}">${fv(empresa_nome, 'NOME DA EMPRESA')}</td>
      </tr>
      <tr>
        <td class="${styles.infoLabel}">Endereço:</td>
        <td class="${styles.infoValue}">${fv(empresa_endereco, 'ENDEREÇO')}</td>
      </tr>
      <tr>
        <td class="${styles.infoLabel}">Cidade:</td>
        <td class="${styles.infoValue}">${fv(empresa_cidade, 'CIDADE - UF, CEP')}</td>
      </tr>
      <tr>
        <td class="${styles.infoLabel}">CNPJ:</td>
        <td class="${styles.infoValue}">${fv(empresa_cnpj, 'CNPJ')}</td>
      </tr>
    </table>`;

    // Declaration text
    h += `<p class="${styles.declaracaoText}">
      Declaro para fins de direito que a empresa qualificada acima declara os seguintes 
      faturamentos dos <strong>${meses.length}</strong> meses, conforme demonstrados abaixo:
    </p>`;

    // Months table
    h += `<table class="${styles.mesTable}">
      <thead>
        <tr>
          <th class="${styles.thMes}">MÊS</th>
          <th class="${styles.thAno}">ANO</th>
          <th class="${styles.thValor}">VALOR</th>
        </tr>
      </thead>
      <tbody>
        ${meses.map((m, i) => `
          <tr class="${i % 2 ? styles.rowAlt : ''}">
            <td class="${styles.tdMes}">${m.mes || '—'}</td>
            <td class="${styles.tdAno}">${m.ano || '—'}</td>
            <td class="${styles.tdValor}">${fmt(m.valor)}</td>
          </tr>
        `).join('')}
        <tr class="${styles.totalRow}">
          <td colspan="2" class="${styles.tdTotalLabel}">Totais</td>
          <td class="${styles.tdTotalValor}">${fmt(total)}</td>
        </tr>
      </tbody>
    </table>`;

    // Signatures
    if (assinatura_socio || assinatura_contador) {
      h += `<div class="${styles.sigBlock}">`;

      if (assinatura_socio) {
        h += `<div class="${styles.sigItem}">
          <div class="${styles.sigLine}"></div>
          <div class="${styles.sigName}">${socio_nome ? socio_nome.toUpperCase() : fv('', 'NOME DO SÓCIO')}</div>
          <div class="${styles.sigRole}">Sócio/Administrador</div>
        </div>`;
      }

      if (assinatura_contador) {
        h += `<div class="${styles.sigItem}">
          <div class="${styles.sigLine}"></div>
          <div class="${styles.sigName}">Contador Responsável</div>
          <div class="${styles.sigRole}">CRC: ${contador_crc || '___________'}</div>
        </div>`;
      }

      h += '</div>';
    }

    // Closing
    h += `<p class="${styles.closing}">Por ser verdade, passo e firmo a presente declaração.</p>`;
    h += `<p class="${styles.datePlace}">
      ${cidade_assinatura || 'Goiânia'}/Goiás, ${data_assinatura || '_____ de _____________ de 2025'}.
    </p>`;

    return h;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify({...store, logo: store.logo?.base64?.slice(0,20)}), total]);

  return (
    <div
      id="doc-preview"
      className={styles.page}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
