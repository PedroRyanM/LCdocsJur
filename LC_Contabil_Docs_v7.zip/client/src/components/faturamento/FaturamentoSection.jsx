import React, { useRef } from 'react';
import { useFaturamentoStore, MESES_PT } from '@/store/faturamento.store';
import { useDocumentoStore }             from '@/store/documento.store';
import { Field, Input, Select }          from '@/components/ui/Field';
import { SectionHeader }                 from '@/components/ui/SectionHeader';
import { Button }                        from '@/components/ui/Button';
import { uploadLogo }                    from '@/services/api';
import { useUiStore }                    from '@/store/ui.store';
import styles from './FaturamentoSection.module.css';

function displayTotal(total) {
  return total.toLocaleString('pt-BR', { style:'currency', currency:'BRL' });
}

const QUICK_PERIODS = [
  { n: 1,  label: '1 mês'   },
  { n: 6,  label: '6 meses' },
  { n: 12, label: '12 meses'},
  { n: 24, label: '24 meses'},
];

export function FaturamentoSection() {
  const store      = useFaturamentoStore();
  const doc        = useDocumentoStore();
  const { showToast } = useUiStore();
  const logoRef    = useRef();

  const f = (key) => ({
    value:    store[key] ?? '',
    onChange: (e) => store.setField(key, e.target.value),
  });

  const total = store.getTotal();

  async function handleLogoUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const data = await uploadLogo(file);
      store.setLogo(data);
      showToast('Logo carregada!', 'success');
    } catch {
      showToast('Erro ao carregar logo', 'error');
    }
    e.target.value = '';
  }

  function handleMesChange(id, key, value) {
    store.updateMes(id, key, value);
    if (key === 'mes' || key === 'ano') store.autoFillFollowing(id);
  }

  return (
    <div>
      {/* ── Logo ──────────────────────────────────────── */}
      <SectionHeader>Logo do Documento</SectionHeader>

      <div className={styles.logoArea}>
        <button
          className={`${styles.logoBtn} ${store.logo ? styles.logoBtnFilled : ''}`}
          onClick={() => logoRef.current?.click()}
          title="Clique para carregar logo"
          type="button"
        >
          {store.logo ? (
            <img
              src={`data:${store.logo.mimetype};base64,${store.logo.base64}`}
              alt="Logo"
              className={styles.logoPreview}
            />
          ) : (
            <div className={styles.logoEmpty}>
              <span className={styles.logoEmptyIcon}>🖼</span>
              <span className={styles.logoEmptyText}>Clique para inserir logo</span>
              <span className={styles.logoEmptyHint}>PNG, JPG, SVG — até 5 MB</span>
            </div>
          )}
        </button>
        <input ref={logoRef} type="file" accept="image/*"
          style={{ display:'none' }} onChange={handleLogoUpload} />
        {store.logo && (
          <Button variant="danger" size="sm" onClick={store.clearLogo}
            style={{ marginTop:'6px', alignSelf:'center' }}>
            ✕ Remover
          </Button>
        )}
      </div>

      {/* ── Company info ──────────────────────────────── */}
      <SectionHeader>Empresa</SectionHeader>

      <div className={styles.prefillRow}>
        <span className={styles.prefillHint}>Importar dados da aba Empresa?</span>
        <Button variant="secondary" size="sm" onClick={() => store.prefillFromDocumento(doc)}>
          ↙ Importar
        </Button>
      </div>

      <Field label="Razão Social">
        <Input placeholder="LARISSA LOBO TREINAMENTOS ACADEMY LTDA" {...f('empresa_nome')} />
      </Field>
      <Field label="Endereço">
        <Input placeholder="AV T 1, 2633, ANDAR SEGUNDO SALA 01, SETOR BUENO" {...f('empresa_endereco')} />
      </Field>
      <Field label="Cidade / CEP">
        <Input placeholder="GOIÂNIA - GO, CEP: 74.210-025" {...f('empresa_cidade')} />
      </Field>
      <Field label="CNPJ">
        <Input placeholder="33.524.871/0001-63" {...f('empresa_cnpj')} />
      </Field>

      {/* ── Faturamento ───────────────────────────────── */}
      <SectionHeader>Faturamento Mensal</SectionHeader>
      <p className="help-text">
        Gere um período automaticamente ou adicione meses manualmente.
        Ao alterar um mês, os seguintes são ajustados em cascata.
      </p>

      {/* Quick period buttons */}
      <div className={styles.quickButtons}>
        {QUICK_PERIODS.map(({ n, label }) => (
          <button
            key={n}
            className={`${styles.quickBtn} ${store.meses.length === n ? styles.quickBtnActive : ''}`}
            onClick={() => store.gerarMeses(n)}
            type="button"
          >
            {label}
          </button>
        ))}
      </div>

      {/* Month table */}
      <div className={styles.mesTable}>
        <div className={styles.mesHeader}>
          <span className={styles.colMes}>Mês</span>
          <span className={styles.colAno}>Ano</span>
          <span className={styles.colValor}>Valor (R$)</span>
          <span className={styles.colAcao} />
        </div>

        {store.meses.map((m, idx) => (
          <div key={m.id} className={`${styles.mesRow} ${idx % 2 ? styles.mesRowAlt : ''}`}>
            <div className={styles.colMes}>
              <Select value={m.mes} onChange={e => handleMesChange(m.id, 'mes', e.target.value)}>
                {MESES_PT.map(mes => <option key={mes} value={mes}>{mes}</option>)}
              </Select>
            </div>
            <div className={styles.colAno}>
              <Input type="number" min="2000" max="2099" value={m.ano}
                onChange={e => handleMesChange(m.id, 'ano', e.target.value)} placeholder="2025" />
            </div>
            <div className={styles.colValor}>
              <Input value={m.valor}
                onChange={e => store.updateMes(m.id, 'valor', e.target.value.replace(/[^\d,.]/g,''))}
                placeholder="0,00" className={styles.valorInput} />
            </div>
            <div className={styles.colAcao}>
              <button className={styles.removeBtn} onClick={() => store.removeMes(m.id)} title="Remover">✕</button>
            </div>
          </div>
        ))}

        <div className={styles.totalRow}>
          <span className={styles.totalLabel}>Total — {store.meses.length} {store.meses.length === 1 ? 'mês' : 'meses'}</span>
          <span className={styles.totalValor}>{displayTotal(total)}</span>
        </div>
      </div>

      <Button variant="secondary" size="sm" fullWidth onClick={store.addMes}
        style={{ marginTop:'8px', borderStyle:'dashed' }}>
        + Adicionar mês
      </Button>

      {/* ── Signatures ────────────────────────────────── */}
      <SectionHeader>Assinaturas</SectionHeader>

      <div className={styles.sigToggles}>
        {[
          { key:'assinatura_socio',    label:'Sócio / Administrador' },
          { key:'assinatura_contador', label:'Contador Responsável'  },
        ].map(({ key, label }) => (
          <label key={key}
            className={`${styles.sigToggle} ${store[key] ? styles.sigToggleOn : ''}`}>
            <input type="checkbox" checked={store[key]}
              onChange={e => store.setField(key, e.target.checked)} />
            <span className={styles.sigToggleIcon}>{store[key] ? '✓' : '○'}</span>
            {label}
          </label>
        ))}
      </div>

      {store.assinatura_socio && (
        <Field label="Nome do Sócio / Administrador">
          <Input placeholder="LARISSA LOBO" {...f('socio_nome')} />
        </Field>
      )}
      {store.assinatura_contador && (
        <Field label="CRC do Contador">
          <Input placeholder="GO-012345/O-5" {...f('contador_crc')} />
        </Field>
      )}

      {/* ── Date ──────────────────────────────────────── */}
      <SectionHeader>Data e Local</SectionHeader>
      <div className="field-row">
        <Field label="Cidade"><Input placeholder="Goiânia" {...f('cidade_assinatura')} /></Field>
        <Field label="Data por extenso"><Input placeholder="04 de abril de 2025" {...f('data_assinatura')} /></Field>
      </div>
    </div>
  );
}
