import React from 'react';
import { useRecentesStore }         from '@/store/recentes.store';
import { useDocumentoPersistencia } from '@/hooks/useDocumentoPersistencia';
import { Button }                   from '@/components/ui/Button';
import styles from './RecentesPanel.module.css';

function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString('pt-BR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

export function RecentesPanel() {
  const { recentes, isOpen, closePanel, removerDocumento, limparTodos } = useRecentesStore();
  const { restaurar } = useDocumentoPersistencia();

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div className={styles.backdrop} onClick={closePanel} />

      {/* Panel */}
      <aside className={styles.panel}>
        <div className={styles.header}>
          <div className={styles.headerLeft}>
            <span className={styles.headerIcon}>📂</span>
            <div>
              <div className={styles.headerTitle}>Documentos Recentes</div>
              <div className={styles.headerSub}>{recentes.length} documento{recentes.length !== 1 ? 's' : ''} salvo{recentes.length !== 1 ? 's' : ''}</div>
            </div>
          </div>
          <div className={styles.headerRight}>
            {recentes.length > 0 && (
              <Button variant="ghost" size="sm" onClick={() => {
                if (confirm('Limpar todos os documentos recentes?')) limparTodos();
              }}>
                Limpar tudo
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={closePanel}>✕</Button>
          </div>
        </div>

        <div className={styles.list}>
          {recentes.length === 0 ? (
            <div className={styles.empty}>
              <span className={styles.emptyIcon}>📄</span>
              <p>Nenhum documento salvo ainda.</p>
              <p className={styles.emptyHint}>
                Use o botão <strong>Salvar</strong> no cabeçalho para guardar o estado atual.
              </p>
            </div>
          ) : (
            recentes.map(doc => (
              <div key={doc.id} className={styles.card}>
                <div className={styles.cardBody}>
                  <div className={styles.cardTitle}>{doc.empresa || 'Empresa não informada'}</div>
                  {doc.natureza && (
                    <div className={styles.cardNatureza}>{doc.natureza}</div>
                  )}
                  <div className={styles.cardMeta}>
                    {doc.cnpj && <span>{doc.cnpj}</span>}
                    <span>·</span>
                    <span>{formatDate(doc.updatedAt || doc.createdAt)}</span>
                  </div>
                </div>
                <div className={styles.cardActions}>
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => { restaurar(doc); closePanel(); }}
                  >
                    Abrir
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => {
                      if (confirm(`Remover "${doc.empresa}"?`)) removerDocumento(doc.id);
                    }}
                  >
                    ✕
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </aside>
    </>
  );
}
