import React, { useRef, useState, useEffect } from 'react';
import { useDocumentoStore }        from '@/store/documento.store';
import { useSociosStore }           from '@/store/socios.store';
import { useClausulasStore }        from '@/store/clausulas.store';
import { useUiStore }               from '@/store/ui.store';
import { useRecentesStore }         from '@/store/recentes.store';
import { useDocumentoPersistencia } from '@/hooks/useDocumentoPersistencia';
import { Button }                   from '@/components/ui/Button';
import { uploadLogo }               from '@/services/api';
import styles from './Header.module.css';

export function Header({ onExportDocx, onExportPdf, exportLoading }) {
  const { logos, setLogo, reset: resetDoc } = useDocumentoStore();
  const { showToast }                       = useUiStore();
  const { togglePanel, recentes }           = useRecentesStore();
  const { salvar }                          = useDocumentoPersistencia();
  const fileRef     = useRef();
  const menuRef     = useRef();
  const [menuOpen, setMenuOpen] = useState(false);

  // Close menu on outside click
  useEffect(() => {
    function handler(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  async function handleAppLogoUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const data = await uploadLogo(file);
      setLogo('app', data);
    } catch {
      showToast('Erro ao carregar logo', 'error');
    }
  }

  function handleNovoDocumento() {
    setMenuOpen(false);
    // Reset all stores
    resetDoc();
    useSociosStore.getState().socios.forEach(s =>
      useSociosStore.getState().removeSocio(s.id)
    );
    useSociosStore.getState().addSocio();
    const { defaultOrder } = useClausulasStore.getState();
    useClausulasStore.setState({ order: [...defaultOrder], texts: {}, labels: {} });
    showToast('Novo documento iniciado', 'success');
  }

  function handleAbrirRecentes() {
    setMenuOpen(false);
    togglePanel();
  }

  return (
    <header className={styles.header}>
      <div className={styles.left}>
        {/* App logo */}
        <button className={styles.logoBtn} onClick={() => fileRef.current?.click()}
          title="Clique para inserir a logo da sua empresa">
          {logos.app ? (
            <img src={`data:${logos.app.mimetype};base64,${logos.app.base64}`}
              alt="Logo" className={styles.logoImg} />
          ) : (
            <div className={styles.logoPlaceholder}>
              <span className={styles.logoIcon}>⬡</span>
              <span className={styles.logoHint}>Inserir logo</span>
            </div>
          )}
        </button>
        <input ref={fileRef} type="file" accept="image/*"
          style={{ display:'none' }} onChange={handleAppLogoUpload} />

        <div className={styles.brand}>
          <span className={styles.brandName}>LC Contábil Docs</span>
          <span className={styles.brandSub}>Gestão Documental</span>
        </div>
      </div>

      <div className={styles.right}>
        {/* Cascade menu: Novo / Abrir */}
        <div className={styles.menuWrapper} ref={menuRef}>
          <button
            className={`${styles.menuBtn} ${menuOpen ? styles.menuBtnOpen : ''}`}
            onClick={() => setMenuOpen(v => !v)}
            title="Novo ou abrir documento"
          >
            <span className={styles.menuBtnIcon}>📁</span>
            <span className={styles.menuBtnLabel}>Documento</span>
            <span className={styles.menuBtnCaret}>{menuOpen ? '▲' : '▼'}</span>
          </button>

          {menuOpen && (
            <div className={styles.dropdown}>
              <button className={styles.dropItem} onClick={handleNovoDocumento}>
                <span className={styles.dropIcon}>✦</span>
                <div className={styles.dropText}>
                  <strong>Novo Documento</strong>
                  <span>Limpar e começar do zero</span>
                </div>
              </button>
              <div className={styles.dropDivider} />
              <button className={styles.dropItem} onClick={handleAbrirRecentes}>
                <span className={styles.dropIcon}>📂</span>
                <div className={styles.dropText}>
                  <strong>Documentos Recentes</strong>
                  <span>{recentes.length} salvo{recentes.length !== 1 ? 's' : ''}</span>
                </div>
                {recentes.length > 0 && (
                  <span className={styles.dropBadge}>{recentes.length}</span>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Recentes badge button (quick access) */}
        <button className={styles.recentesBtn} onClick={togglePanel} title="Documentos recentes">
          📂
          {recentes.length > 0 && (
            <span className={styles.recentesBadge}>{recentes.length}</span>
          )}
        </button>

        {/* Save */}
        <Button variant="export" size="sm" icon="💾" onClick={() => salvar()}>
          Salvar
        </Button>

        <div className={styles.divider} />

        <Button variant="export" size="sm" icon="⬇"
          loading={exportLoading === 'docx'} onClick={onExportDocx}>
          DOCX
        </Button>
        <Button variant="export" size="sm" icon="⬇"
          loading={exportLoading === 'pdf'} onClick={onExportPdf}>
          PDF
        </Button>
      </div>
    </header>
  );
}
