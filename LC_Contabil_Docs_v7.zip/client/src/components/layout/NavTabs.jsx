import React from 'react';
import { useUiStore }      from '@/store/ui.store';
import { useDocTypeStore } from '@/store/docType.store';
import { useModificacoesStore } from '@/store/modificacoes.store';
import styles from './NavTabs.module.css';

const ALTERACAO_TABS = [
  { id: 'empresa',      label: 'Empresa',      icon: '🏢' },
  { id: 'modificacoes', label: 'Modificações',  icon: '✅' },
  { id: 'socios',       label: 'Sócios',        icon: '👥' },
  { id: 'clausulas',    label: 'Cláusulas',     icon: '📋' },
  { id: 'cnae',         label: 'CNAEs',         icon: '🔍' },
  { id: 'logos',        label: 'Logos',         icon: '🖼' },
];

export function NavTabs() {
  const { activeSection, setSection } = useUiStore();
  const { docType }   = useDocTypeStore();
  const { selecionadas } = useModificacoesStore();

  if (docType === 'faturamento') {
    return (
      <div className={styles.faturamentoBar}>
        <span className={styles.faturamentoLabel}>📊 Declaração de Faturamento</span>
        <span className={styles.faturamentoHint}>Preencha os campos ao lado</span>
      </div>
    );
  }

  return (
    <nav className={styles.nav}>
      {ALTERACAO_TABS.map(tab => {
        const isActive = activeSection === tab.id;
        // Badge for modificacoes tab
        const badge = tab.id === 'modificacoes' && selecionadas.size > 0
          ? selecionadas.size : null;
        return (
          <button
            key={tab.id}
            className={`${styles.tab} ${isActive ? styles.active : ''}`}
            onClick={() => setSection(tab.id)}
            aria-current={isActive ? 'page' : undefined}
          >
            <span className={styles.icon}>{tab.icon}</span>
            <span className={styles.label}>{tab.label}</span>
            {badge && <span className={styles.badge}>{badge}</span>}
            {isActive && <span className={styles.activeBar} />}
          </button>
        );
      })}
    </nav>
  );
}
