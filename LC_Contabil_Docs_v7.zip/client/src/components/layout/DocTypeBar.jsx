import React from 'react';
import { useDocTypeStore } from '@/store/docType.store';
import styles from './DocTypeBar.module.css';

const DOC_TYPES = [
  {
    id:      'alteracao',
    label:   'Alteração Contratual',
    icon:    '📄',
    desc:    'Transformação, inclusão de sócios, sede...',
  },
  {
    id:      'faturamento',
    label:   'Declaração de Faturamento',
    icon:    '📊',
    desc:    'Demonstrativo de previsão de faturamento',
  },
];

export function DocTypeBar() {
  const { docType, setDocType } = useDocTypeStore();

  return (
    <div className={styles.bar}>
      <span className={styles.barLabel}>Tipo de Documento</span>
      <div className={styles.tabs}>
        {DOC_TYPES.map(dt => (
          <button
            key={dt.id}
            className={`${styles.tab} ${docType === dt.id ? styles.tabActive : ''}`}
            onClick={() => setDocType(dt.id)}
          >
            <span className={styles.tabIcon}>{dt.icon}</span>
            <div className={styles.tabText}>
              <span className={styles.tabLabel}>{dt.label}</span>
              <span className={styles.tabDesc}>{dt.desc}</span>
            </div>
            {docType === dt.id && <span className={styles.tabCheck}>✓</span>}
          </button>
        ))}
      </div>
    </div>
  );
}
