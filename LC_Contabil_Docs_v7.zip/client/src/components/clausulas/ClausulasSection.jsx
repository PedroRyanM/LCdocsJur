import React, { useState } from 'react';
import {
  DndContext, closestCenter, PointerSensor,
  useSensor, useSensors,
} from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';

import { useClausulasStore } from '@/store/clausulas.store';
import { useUiStore }        from '@/store/ui.store';
import { ClausulaItem }      from './ClausulaItem';
import { ClausulaEditor }    from './ClausulaEditor';
import { SectionHeader }     from '@/components/ui/SectionHeader';
import { Button }            from '@/components/ui/Button';
import { useModal }          from '@/components/ui/Modal';
import styles from './ClausulasSection.module.css';

const SECAO_COLORS = { PREAMBULO:'preambulo', ALTERACAO:'alteracao', CONTRATO:'contrato' };
function getSecaoColor(id) { return SECAO_COLORS[id] || 'custom'; }

export function ClausulasSection() {
  const {
    order, definitions, getAllSecoes, customSecoes,
    addClausula, addClausulaLivre, addSecaoCustom, updateSecao, removeSecaoCustom,
    moveClausula, getOrdinals, loading,
  } = useClausulasStore();
  const { showToast } = useUiStore();
  const modal         = useModal();

  const [selectedToAdd, setSelectedToAdd] = useState('');
  const [selectedSecao, setSelectedSecao] = useState('CONTRATO');

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));
  const ordinals  = getOrdinals();
  const allSecoes = getAllSecoes();

  // Group by section
  const grouped = {};
  Object.keys(allSecoes).forEach(id => { grouped[id] = []; });
  order.forEach((id, idx) => {
    const def = definitions[id];
    if (def?.secao && grouped[def.secao] !== undefined)
      grouped[def.secao].push({ id, idx, ordinal: ordinals[idx] });
  });

  function handleDragEnd({ active, over }) {
    if (!over || active.id === over.id) return;
    const fromIdx = parseInt(active.id.split('__')[1], 10);
    const toIdx   = parseInt(over.id.split('__')[1], 10);
    if (isNaN(fromIdx) || isNaN(toIdx)) return;
    if (definitions[order[fromIdx]]?.secao !== definitions[order[toIdx]]?.secao) {
      showToast('Mova apenas dentro da mesma seção.', 'error'); return;
    }
    moveClausula(fromIdx, toIdx);
  }

  function handleAdd() {
    if (!selectedToAdd) return;
    if (!addClausula(selectedToAdd)) { showToast('Cláusula já está no documento.', 'error'); return; }
    showToast('Cláusula adicionada!', 'success');
    setSelectedToAdd('');
  }

  function handleAddLivre() {
    const id = addClausulaLivre(selectedSecao);
    useClausulasStore.getState().openEditor(id);
    showToast('Cláusula livre adicionada — edite o texto.', 'success');
  }

  async function handleAddSecao() {
    const label = await modal.prompt({
      title:       'Nova Seção',
      message:     'Dê um nome para a nova seção do documento:',
      placeholder: 'Ex: Disposições Finais',
      confirmLabel:'Criar Seção',
    });
    if (!label?.trim()) return;
    const ponte = await modal.prompt({
      title:       'Texto de transição',
      message:     'Texto introdutório antes desta seção (opcional):',
      placeholder: 'Deixe vazio para nenhum',
      confirmLabel:'Confirmar',
      optional:    true,
    });
    addSecaoCustom(label.trim(), (ponte || '').trim());
    showToast(`Seção "${label}" criada!`, 'success');
  }

  async function handleRenameSecao(secaoId, currentLabel) {
    const label = await modal.prompt({
      title:       'Renomear Seção',
      message:     'Novo nome:',
      placeholder: currentLabel,
      confirmLabel:'Renomear',
      defaultValue: currentLabel,
    });
    if (label?.trim()) updateSecao(secaoId, { label: label.trim() });
  }

  async function handleRemoveSecao(secaoId, label) {
    const ok = await modal.confirm({
      title:   'Remover Seção',
      message: `Remover a seção "${label}" e todas as suas cláusulas? Esta ação não pode ser desfeita.`,
      danger:  true,
      confirmLabel: 'Remover',
    });
    if (ok) removeSecaoCustom(secaoId);
  }

  const available = Object.values(definitions).filter(
    d => d.id === 'CLAUSULA_LIVRE' || !order.includes(d.id)
  );

  if (loading) return <p className="help-text">Carregando cláusulas…</p>;

  return (
    <div>
      <SectionHeader>Gerenciador de Cláusulas</SectionHeader>
      <p className="help-text">
        Arraste ⠿ para reordenar dentro da mesma seção. Passe o mouse sobre uma cláusula para ver as ações.
      </p>

      {/* Row 1: add predefined clause */}
      <div className={styles.toolbar}>
        <select className={styles.addSelect} value={selectedToAdd}
          onChange={e => setSelectedToAdd(e.target.value)}>
          <option value="">— Adicionar cláusula predefinida —</option>
          {Object.values(allSecoes).map(sec => (
            <optgroup key={sec.id} label={sec.label}>
              {available.filter(d => d.secao === sec.id).map(d => (
                <option key={d.id} value={d.id}>{d.label}</option>
              ))}
            </optgroup>
          ))}
        </select>
        <Button variant="primary" size="sm" onClick={handleAdd} disabled={!selectedToAdd}>
          + Adicionar
        </Button>
      </div>

      {/* Row 2: free clause + new section — full-width buttons stacked */}
      <div className={styles.secondaryRow}>
        <div className={styles.livreBlock}>
          <span className={styles.livreLabel}>Cláusula livre em:</span>
          <select className={styles.secaoSelect} value={selectedSecao}
            onChange={e => setSelectedSecao(e.target.value)}>
            {Object.values(allSecoes).filter(s => s.id !== 'PREAMBULO').map(s => (
              <option key={s.id} value={s.id}>{s.label}</option>
            ))}
          </select>
          <Button variant="secondary" size="sm" onClick={handleAddLivre}>
            + Livre
          </Button>
        </div>
        <Button variant="secondary" size="sm" onClick={handleAddSecao}>
          ⊞ Nova Seção
        </Button>
      </div>

      {/* DnD + sections */}
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        {Object.entries(grouped).map(([secaoId, items]) => {
          const secao     = allSecoes[secaoId];
          if (!secao) return null;
          const isCustom  = !!customSecoes[secaoId];
          const colorKey  = getSecaoColor(secaoId);
          const sortableIds = items.map(({ id, idx }) => `${id}__${idx}`);

          return (
            <div key={secaoId} className={styles.secaoBlock}>
              <div className={`${styles.secaoHeader} ${styles[colorKey]}`}>
                <div className={styles.secaoLeft}>
                  <span className={styles.secaoTitle}>{secao.label}</span>
                  {isCustom && <span className={styles.customBadge}>personalizada</span>}
                </div>
                {isCustom && (
                  <div className={styles.secaoActions}>
                    <button className={styles.secaoBtn} title="Renomear"
                      onClick={() => handleRenameSecao(secaoId, secao.label)}>✎</button>
                    <button className={styles.secaoBtnDanger} title="Remover"
                      onClick={() => handleRemoveSecao(secaoId, secao.label)}>✕</button>
                  </div>
                )}
              </div>

              <SortableContext items={sortableIds} strategy={verticalListSortingStrategy}>
                <div className={styles.list}>
                  {items.length === 0 && (
                    <p className={styles.emptyMsg}>Nenhuma cláusula nesta seção.</p>
                  )}
                  {items.map(({ id, idx, ordinal }) => (
                    <ClausulaItem key={`${id}__${idx}`} clausulaId={id} index={idx} ordinalNum={ordinal} />
                  ))}
                </div>
              </SortableContext>
            </div>
          );
        })}
      </DndContext>

      <ClausulaEditor />
    </div>
  );
}
