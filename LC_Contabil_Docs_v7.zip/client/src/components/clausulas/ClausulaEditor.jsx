import React, { useRef } from 'react';
import { useClausulasStore } from '@/store/clausulas.store';
import { Button }            from '@/components/ui/Button';
import styles from './ClausulaEditor.module.css';

// Todas as variáveis disponíveis com descrição legível
const VARIAVEIS = [
  { key: 'empresa_nome_atual',  label: 'Nome Atual',       grupo: 'Empresa' },
  { key: 'empresa_nome_novo',   label: 'Nome Novo',        grupo: 'Empresa' },
  { key: 'empresa_fantasia',    label: 'Nome Fantasia',    grupo: 'Empresa' },
  { key: 'empresa_cnpj',        label: 'CNPJ',             grupo: 'Empresa' },
  { key: 'empresa_nire',        label: 'NIRE',             grupo: 'Empresa' },
  { key: 'sede_completa',       label: 'Sede Completa',    grupo: 'Sede'    },
  { key: 'cap_quotas',          label: 'Total de Quotas',  grupo: 'Capital' },
  { key: 'cap_valor_quota',     label: 'Valor / Quota',    grupo: 'Capital' },
  { key: 'cap_total',           label: 'Capital Total',    grupo: 'Capital' },
  { key: 'objeto_social',       label: 'Objeto Social',    grupo: 'Objeto'  },
  { key: 'admins',              label: 'Administrador(es)',grupo: 'Sócios'  },
  { key: 'data_inicio',         label: 'Início Atividades',grupo: 'Datas'   },
  { key: 'data_assinatura',     label: 'Data Assinatura',  grupo: 'Datas'   },
  { key: 'cidade_assinatura',   label: 'Cidade Assinatura',grupo: 'Datas'   },
  { key: 'foro',                label: 'Foro Eleito',      grupo: 'Datas'   },
];

const GRUPOS = [...new Set(VARIAVEIS.map(v => v.grupo))];

export function ClausulaEditor() {
  const {
    editingId, definitions,
    getClausulaText, setClausulaText, resetClausulaText,
    hasCustomText, closeEditor,
  } = useClausulasStore();
  const textareaRef = useRef();

  if (!editingId) return null;

  const def        = definitions[editingId];
  const text       = getClausulaText(editingId);
  const isModified = hasCustomText(editingId);

  // Insert {{key}} at cursor position in textarea
  function insertVar(key) {
    const ta  = textareaRef.current;
    if (!ta) return;
    const start = ta.selectionStart;
    const end   = ta.selectionEnd;
    const tag   = `{{${key}}}`;
    const next  = text.slice(0, start) + tag + text.slice(end);
    setClausulaText(editingId, next);
    // Restore cursor after tag
    requestAnimationFrame(() => {
      ta.focus();
      ta.setSelectionRange(start + tag.length, start + tag.length);
    });
  }

  return (
    <div className={styles.editor}>
      <div className={styles.editorHeader}>
        <div className={styles.editorTitle}>
          <span>✏</span>
          <span>{def?.label}</span>
          {isModified && <span className={styles.modifiedBadge}>modificado</span>}
        </div>
        <Button variant="ghost" size="sm" onClick={closeEditor}>✕</Button>
      </div>

      {/* Variable tags */}
      <div className={styles.varPanel}>
        <div className={styles.varPanelLabel}>
          Clique em uma variável para inserir no cursor:
        </div>
        {GRUPOS.map(grupo => (
          <div key={grupo} className={styles.varGrupo}>
            <span className={styles.varGrupoLabel}>{grupo}</span>
            <div className={styles.varTags}>
              {VARIAVEIS.filter(v => v.grupo === grupo).map(v => (
                <button
                  key={v.key}
                  className={styles.varTag}
                  onClick={() => insertVar(v.key)}
                  title={`Inserir {{${v.key}}}`}
                  draggable
                  onDragStart={(e) => e.dataTransfer.setData('text/plain', `{{${v.key}}}`)}
                >
                  {v.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Textarea — accepts drop of variable tags */}
      <textarea
        ref={textareaRef}
        className={styles.textarea}
        rows={7}
        value={text}
        spellCheck={false}
        onChange={(e) => setClausulaText(editingId, e.target.value)}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          const tag   = e.dataTransfer.getData('text/plain');
          const ta    = textareaRef.current;
          if (!ta || !tag) return;
          const start = ta.selectionStart;
          const next  = text.slice(0, start) + tag + text.slice(start);
          setClausulaText(editingId, next);
        }}
      />

      <div className={styles.editorFooter}>
        <span className={styles.hint}>
          Arraste ou clique nas tags. Digite <code>{'{{variavel}}'}</code> manualmente.
        </span>
        {isModified && (
          <Button variant="ghost" size="sm" onClick={() => resetClausulaText(editingId)}>
            ↺ Restaurar padrão
          </Button>
        )}
      </div>
    </div>
  );
}
