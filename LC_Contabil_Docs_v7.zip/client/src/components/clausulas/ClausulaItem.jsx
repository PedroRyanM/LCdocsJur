import React, { useState } from 'react';
import { useSortable }       from '@dnd-kit/sortable';
import { CSS }               from '@dnd-kit/utilities';
import { useClausulasStore } from '@/store/clausulas.store';
import { useModal }          from '@/components/ui/Modal';
import { ordinal }           from '@/constants/ordinals';
import styles from './ClausulaItem.module.css';

export function ClausulaItem({ clausulaId, index, ordinalNum }) {
  const {
    definitions, removeClausula, openEditor,
    hasCustomText, getClausulaLabel, setClausulaLabel,
  } = useClausulasStore();
  const modal = useModal();

  const def        = definitions[clausulaId];
  const isAbertura = clausulaId === 'ABERTURA';
  const isModified = hasCustomText(clausulaId);
  const label      = getClausulaLabel(clausulaId);

  const {
    attributes, listeners,
    setNodeRef, transform, transition, isDragging,
  } = useSortable({ id: `${clausulaId}__${index}`, disabled: isAbertura });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
  };

  if (!def) return null;

  async function handleRename() {
    const novo = await modal.prompt({
      title:        'Renomear Cláusula',
      message:      'Digite o novo nome desta cláusula:',
      defaultValue: label,
      placeholder:  label,
      confirmLabel: 'Renomear',
    });
    if (novo?.trim()) setClausulaLabel(clausulaId, novo.trim());
  }

  async function handleRemove() {
    const ok = await modal.confirm({
      title:        'Remover Cláusula',
      message:      `Remover "${label}" do documento?`,
      confirmLabel: 'Remover',
      danger:       true,
    });
    if (ok) removeClausula(index);
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={[
        styles.item,
        isDragging ? styles.dragging : '',
        isAbertura ? styles.abertura : '',
        isModified ? styles.modified : '',
      ].join(' ')}
    >
      {/* Drag handle */}
      {!isAbertura ? (
        <span className={`${styles.handle} drag-handle`} {...attributes} {...listeners}>
          ⠿
        </span>
      ) : (
        <span className={styles.anchor} title="Preâmbulo — posição fixa">⚓</span>
      )}

      <span className={styles.name} title={label}>{label}</span>

      {isModified && <span className={styles.modBadge} title="Texto personalizado">✎</span>}

      {def.numerada && ordinalNum != null && (
        <span className={styles.badge}>{ordinal(ordinalNum)}</span>
      )}

      <div className={styles.actions}>
        <button className={styles.actionBtn} title="Renomear" onClick={handleRename}>✎</button>
        <button className={styles.actionBtn} title="Editar texto" onClick={() => openEditor(clausulaId)}>📝</button>
        {def.removivel !== false && !isAbertura && (
          <button className={`${styles.actionBtn} ${styles.actionBtnDanger}`}
            title="Remover" onClick={handleRemove}>✕</button>
        )}
      </div>
    </div>
  );
}
