import React, { useState, useCallback, useRef } from 'react';
import { useDocumentoStore } from '@/store/documento.store';
import { useUiStore }        from '@/store/ui.store';
import { searchCnae }        from '@/services/api';
import { SectionHeader }     from '@/components/ui/SectionHeader';
import { Input }             from '@/components/ui/Field';
import { Button }            from '@/components/ui/Button';
import styles from './CNAESection.module.css';

function useDebounce(fn, delay) {
  const timer = useRef(null);
  return useCallback((...args) => {
    clearTimeout(timer.current);
    timer.current = setTimeout(() => fn(...args), delay);
  }, [fn, delay]);
}

export function CNAESection() {
  const { cnae_list, addCnae, removeCnae, objeto_social, setObjetoManual } = useDocumentoStore();
  const { showToast } = useUiStore();

  const [query,   setQuery]   = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [manualMode, setManualMode] = useState(false);

  const doSearch = useCallback(async (q) => {
    if (q.length < 2) { setResults([]); return; }
    setSearching(true);
    try {
      const { results: r } = await searchCnae(q);
      setResults(r);
    } catch {
      showToast('Erro na busca de CNAEs', 'error');
    } finally {
      setSearching(false);
    }
  }, [showToast]);

  const debouncedSearch = useDebounce(doSearch, 320);

  function handleQueryChange(e) {
    const q = e.target.value;
    setQuery(q);
    debouncedSearch(q);
  }

  function handleAdd(cnae) {
    addCnae({ codigo: cnae.codigo, denominacao: cnae.denominacao });
    showToast(`${cnae.codigo} adicionado`, 'success');
  }

  return (
    <div>
      <SectionHeader>Objeto Social — CNAEs</SectionHeader>
      <p className="help-text">
        Pesquise e adicione as atividades da empresa. Elas compõem automaticamente
        o campo "Objeto Social" no documento.
      </p>

      {/* Toggle manual / cnae */}
      <div className={styles.modeToggle}>
        <button
          className={`${styles.modeBtn} ${!manualMode ? styles.modeBtnActive : ''}`}
          onClick={() => setManualMode(false)}
        >
          Busca por CNAE
        </button>
        <button
          className={`${styles.modeBtn} ${manualMode ? styles.modeBtnActive : ''}`}
          onClick={() => setManualMode(true)}
        >
          Texto manual
        </button>
      </div>

      {manualMode ? (
        <div>
          <textarea
            className={styles.manualArea}
            rows={5}
            value={objeto_social}
            onChange={(e) => setObjetoManual(e.target.value)}
            placeholder="Descreva o objeto social manualmente..."
          />
        </div>
      ) : (
        <>
          {/* Search bar */}
          <div className={styles.searchBar}>
            <Input
              placeholder="Pesquisar por código ou descrição... ex: ferragens, 47.63"
              value={query}
              onChange={handleQueryChange}
            />
            {searching && <span className={styles.spinner} />}
          </div>

          {/* Results */}
          {results.length > 0 && (
            <div className={styles.results}>
              {results.map((r) => (
                <div key={r.codigo} className={styles.resultItem}>
                  <div className={styles.resultInfo}>
                    <span className={styles.resultCode}>{r.codigo}</span>
                    <span className={styles.resultName}>{r.denominacao}</span>
                    <span className={styles.resultBreadcrumb}>{r.breadcrumb}</span>
                  </div>
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => handleAdd(r)}
                    disabled={cnae_list.some(c => c.codigo === r.codigo)}
                  >
                    {cnae_list.some(c => c.codigo === r.codigo) ? '✓' : '+ Add'}
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Selected CNAEs */}
          {cnae_list.length > 0 && (
            <div className={styles.selectedBlock}>
              <SectionHeader>Atividades Selecionadas</SectionHeader>
              {cnae_list.map((c) => (
                <div key={c.codigo} className={styles.selectedItem}>
                  <span className={styles.resultCode}>{c.codigo}</span>
                  <span className={styles.resultName}>{c.denominacao}</span>
                  <Button variant="danger" size="sm" onClick={() => removeCnae(c.codigo)}>
                    ✕
                  </Button>
                </div>
              ))}
            </div>
          )}

          {cnae_list.length === 0 && query.length < 2 && (
            <p className={styles.hint}>
              💡 Digite ao menos 2 caracteres para buscar entre 673 atividades do CNAE 2.0
            </p>
          )}
        </>
      )}
    </div>
  );
}
