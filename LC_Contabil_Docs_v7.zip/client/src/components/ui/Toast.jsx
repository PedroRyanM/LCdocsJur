import React from 'react';
import { useUiStore } from '@/store/ui.store';
import styles from './Toast.module.css';

export function Toast() {
  const { toast, clearToast } = useUiStore();
  if (!toast) return null;
  return (
    <div className={`${styles.toast} ${styles[toast.type]}`} onClick={clearToast}>
      <span>{toast.message}</span>
      <button className={styles.close} aria-label="Fechar">✕</button>
    </div>
  );
}
