import React from 'react';
import styles from './Field.module.css';

/** Labeled input wrapper */
export function Field({ label, children, row = false }) {
  return (
    <div className={row ? styles.fieldRow : styles.fieldGroup}>
      {label && <label className={styles.label}>{label}</label>}
      {children}
    </div>
  );
}

/** Text input */
export function Input({ className = '', ...props }) {
  return <input className={`${styles.control} ${className}`} {...props} />;
}

/** Select */
export function Select({ children, className = '', ...props }) {
  return (
    <select className={`${styles.control} ${className}`} {...props}>
      {children}
    </select>
  );
}

/** Textarea */
export function Textarea({ className = '', rows = 4, ...props }) {
  return (
    <textarea
      rows={rows}
      className={`${styles.control} ${styles.textarea} ${className}`}
      {...props}
    />
  );
}
