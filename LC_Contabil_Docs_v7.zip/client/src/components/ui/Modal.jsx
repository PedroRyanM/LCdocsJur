import React, { useState, useEffect, useRef, createContext, useContext, useCallback } from 'react';
import styles from './Modal.module.css';

// ── Context ───────────────────────────────────────────────────────────────────
const ModalContext = createContext(null);

export function useModal() {
  return useContext(ModalContext);
}

// ── Provider ──────────────────────────────────────────────────────────────────
export function ModalProvider({ children }) {
  const [queue, setQueue] = useState([]);
  const resolveRef = useRef(null);

  const openModal = useCallback((config) => {
    return new Promise((resolve) => {
      resolveRef.current = resolve;
      setQueue([config]);
    });
  }, []);

  // prompt: returns string | null
  const prompt = useCallback((config) => openModal({ ...config, type: 'prompt' }), [openModal]);

  // confirm: returns boolean
  const confirm = useCallback((config) => openModal({ ...config, type: 'confirm' }), [openModal]);

  function handleClose(result) {
    setQueue([]);
    resolveRef.current?.(result);
    resolveRef.current = null;
  }

  const api = { prompt, confirm };

  return (
    <ModalContext.Provider value={api}>
      {children}
      {queue.map((cfg, i) => (
        <ModalDialog key={i} config={cfg} onClose={handleClose} />
      ))}
    </ModalContext.Provider>
  );
}

// ── Dialog ────────────────────────────────────────────────────────────────────
function ModalDialog({ config, onClose }) {
  const { type, title, message, placeholder, confirmLabel = 'Confirmar',
          cancelLabel = 'Cancelar', danger = false, optional = false,
          defaultValue = '' } = config;

  const [value, setValue] = useState(defaultValue);
  const inputRef = useRef();

  useEffect(() => {
    // Focus input or confirm button after mount
    requestAnimationFrame(() => {
      if (type === 'prompt') inputRef.current?.focus();
    });
  }, [type]);

  function handleConfirm() {
    if (type === 'prompt') onClose(value || (optional ? '' : null));
    else onClose(true);
  }
  function handleCancel() {
    onClose(type === 'prompt' ? null : false);
  }
  function handleKeyDown(e) {
    if (e.key === 'Enter')  handleConfirm();
    if (e.key === 'Escape') handleCancel();
  }

  return (
    <div className={styles.overlay} onClick={(e) => { if (e.target === e.currentTarget) handleCancel(); }}>
      <div className={styles.dialog} role="dialog" aria-modal="true">
        {/* Header */}
        <div className={`${styles.header} ${danger ? styles.headerDanger : ''}`}>
          <span className={styles.icon}>{danger ? '⚠' : type === 'prompt' ? '✎' : '?'}</span>
          <span className={styles.title}>{title}</span>
        </div>

        {/* Body */}
        <div className={styles.body}>
          {message && <p className={styles.message}>{message}</p>}

          {type === 'prompt' && (
            <input
              ref={inputRef}
              type="text"
              className={styles.input}
              value={value}
              placeholder={placeholder || ''}
              onChange={e => setValue(e.target.value)}
              onKeyDown={handleKeyDown}
            />
          )}
        </div>

        {/* Footer */}
        <div className={styles.footer}>
          <button className={styles.btnCancel} onClick={handleCancel}>
            {cancelLabel}
          </button>
          <button
            className={`${styles.btnConfirm} ${danger ? styles.btnDanger : ''}`}
            onClick={handleConfirm}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
