import React from 'react';
import styles from './SectionHeader.module.css';

export function SectionHeader({ children }) {
  return (
    <div className={styles.header}>
      <span className={styles.label}>{children}</span>
      <span className={styles.line} />
    </div>
  );
}
