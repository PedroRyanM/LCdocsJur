import React from 'react';
import styles from './Button.module.css';

/**
 * Button
 * variant: 'primary' | 'secondary' | 'ghost' | 'danger' | 'export'
 * size:    'sm' | 'md' | 'lg'
 */
export function Button({
  children,
  variant = 'secondary',
  size = 'md',
  icon,
  loading = false,
  disabled = false,
  fullWidth = false,
  onClick,
  type = 'button',
  ...props
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      className={[
        styles.btn,
        styles[variant],
        styles[size],
        fullWidth ? styles.fullWidth : '',
        loading   ? styles.loading   : '',
      ].join(' ')}
      {...props}
    >
      {loading ? (
        <span className={styles.spinner} aria-hidden />
      ) : icon ? (
        <span className={styles.icon}>{icon}</span>
      ) : null}
      <span>{children}</span>
    </button>
  );
}
