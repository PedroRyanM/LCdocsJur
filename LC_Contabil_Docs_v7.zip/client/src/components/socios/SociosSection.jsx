import React, { useMemo } from 'react';
import { useSociosStore }       from '@/store/socios.store';
import { useModificacoesStore } from '@/store/modificacoes.store';
import { SocioCard }            from './SocioCard';
import { SectionHeader }        from '@/components/ui/SectionHeader';
import styles from './SociosSection.module.css';

const PAPEL_OPTIONS = [
  {
    papel:   'vigente',
    label:   'Sócio Vigente',
    desc:    'No preâmbulo',
    color:   '#1E5C3A',
    // Always allowed — vigentes são o QSA atual
    modReq:  null,
    modLabel: null,
  },
  {
    papel:   'novo',
    label:   'Sócio Entrante',
    desc:    'Cláusula de entrada',
    color:   '#1A3A5C',
    modReq:  'entrada_socio',
    modLabel: '"Entrada de Sócio"',
  },
  {
    papel:   'retirante',
    label:   'Sócio Retirante',
    desc:    'Saindo da sociedade',
    color:   '#903010',
    modReq:  'saida_socio',
    modLabel: '"Saída de Sócio"',
  },
];

function parseQts(v) {
  return parseFloat(String(v||0).replace(/\./g,'').replace(',','.')) || 0;
}
function fmtNum(n) { return n.toLocaleString('pt-BR'); }
function fmtPct(n) { return n.toFixed(2).replace('.',',') + '%'; }

export function SociosSection() {
  const { socios, addSocio }  = useSociosStore();
  const { selecionadas }      = useModificacoesStore();

  const ativos     = socios.filter(s => s.papel !== 'retirante');
  const totalQts   = useMemo(() => ativos.reduce((a,s)=>a+parseQts(s.quotas),0), [ativos]);
  const totalVal   = useMemo(() => ativos.reduce((a,s)=>a+parseQts(s.quotas_valor),0), [ativos]);

  return (
    <div>
      <SectionHeader>Quadro Societário</SectionHeader>
      <p className="help-text">
        Defina o papel de cada sócio. <strong>Vigentes</strong> e <strong>retirantes</strong> são qualificados
        no preâmbulo. <strong>Entrantes</strong> aparecem na cláusula de entrada.
      </p>

      {socios.map((s, i) => (
        <SocioCard key={s.id} socio={s} index={i} />
      ))}

      {/* Add buttons — restricted by selected modifications */}
      <div className={styles.addGrid}>
        {PAPEL_OPTIONS.map(opt => {
          const blocked = opt.modReq && !selecionadas.has(opt.modReq);
          return (
            <button
              key={opt.papel}
              className={`${styles.addBtn} ${styles[opt.papel]} ${blocked ? styles.addBtnBlocked : ''}`}
              onClick={() => !blocked && addSocio({ papel: opt.papel })}
              style={{ '--role-color': opt.color }}
              title={blocked ? `Marque ${opt.modLabel} na aba Modificações para adicionar` : undefined}
              disabled={blocked}
            >
              <span className={styles.addIcon}>{blocked ? '🔒' : '+'}</span>
              <div className={styles.addText}>
                <span className={styles.addLabel}>{opt.label}</span>
                <span className={styles.addDesc}>
                  {blocked ? `Requer ${opt.modLabel}` : opt.desc}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Capital redistribution table */}
      {ativos.length > 0 && (
        <div className={styles.redistribBlock}>
          <SectionHeader>Redistribuição do Capital Social</SectionHeader>
          <p className="help-text">
            Calculado automaticamente pelas quotas de cada sócio ativo.
          </p>
          <div className={styles.redistribTable}>
            <div className={styles.redistribHeader}>
              <span className={styles.colNome}>Nome do Sócio</span>
              <span className={styles.colQts}>Qtd Quotas</span>
              <span className={styles.colVal}>Valor (R$)</span>
              <span className={styles.colPct}>%</span>
            </div>
            {ativos.map((s, i) => {
              const qts = parseQts(s.quotas);
              const val = parseQts(s.quotas_valor);
              const pct = totalQts > 0 ? (qts / totalQts) * 100 : 0;
              return (
                <div key={s.id}
                  className={`${styles.redistribRow} ${s.papel==='novo' ? styles.redistribRowNovo : ''} ${i%2 ? styles.redistribRowAlt : ''}`}>
                  <span className={styles.colNome}>{s.nome || <em className={styles.empty}>[nome]</em>}</span>
                  <span className={styles.colQts}>{qts > 0 ? fmtNum(qts) : '—'}</span>
                  <span className={styles.colVal}>{val > 0 ? `R$ ${fmtNum(val)}` : '—'}</span>
                  <span className={styles.colPct}>{totalQts > 0 ? fmtPct(pct) : '—'}</span>
                </div>
              );
            })}
            <div className={styles.redistribTotal}>
              <span className={styles.colNome}>TOTAL</span>
              <span className={styles.colQts}>{totalQts > 0 ? fmtNum(totalQts) : '—'}</span>
              <span className={styles.colVal}>{totalVal > 0 ? `R$ ${fmtNum(totalVal)}` : '—'}</span>
              <span className={styles.colPct}>{totalQts > 0 ? '100%' : '—'}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
