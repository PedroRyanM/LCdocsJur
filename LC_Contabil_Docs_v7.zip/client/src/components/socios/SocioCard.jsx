import React from 'react';
import { useSociosStore } from '@/store/socios.store';
import { Field, Input, Select } from '@/components/ui/Field';
import { Button } from '@/components/ui/Button';
import styles from './SocioCard.module.css';

const PAPEL_LABELS = {
  vigente:   { label: 'Sócio Vigente',   color: '#2D6A4F', bg: 'rgba(45,106,79,0.10)' },
  novo:      { label: 'Sócio Entrante',  color: '#1A3A5C', bg: 'rgba(26,58,92,0.10)'  },
  retirante: { label: 'Sócio Retirante', color: '#903010', bg: 'rgba(144,48,16,0.10)' },
};

export function SocioCard({ socio, index }) {
  const { updateSocio, removeSocio } = useSociosStore();
  const u = (key) => ({
    value:    socio[key] ?? '',
    onChange: (e) => updateSocio(socio.id, key, e.target.value),
  });

  const papelMeta = PAPEL_LABELS[socio.papel] || PAPEL_LABELS.vigente;

  return (
    <div className={styles.card} style={{ borderLeftColor: papelMeta.color }}>
      <div className={styles.cardHeader}>
        <div className={styles.headerLeft}>
          <span className={styles.num}>SÓCIO {index + 1}</span>
          <span className={styles.papelBadge} style={{ color: papelMeta.color, background: papelMeta.bg }}>
            {papelMeta.label}
          </span>
        </div>
        <Button variant="danger" size="sm" onClick={() => removeSocio(socio.id)}>
          Remover
        </Button>
      </div>

      {/* Papel — destacado no topo */}
      <Field label="Papel no Processo">
        <Select value={socio.papel} onChange={(e) => updateSocio(socio.id, 'papel', e.target.value)}>
          <option value="vigente">Sócio Vigente (aparece no preâmbulo)</option>
          <option value="novo">Sócio Entrante (aparece nas cláusulas)</option>
          <option value="retirante">Sócio Retirante (aparece no preâmbulo — saindo)</option>
        </Select>
      </Field>

      <Field label="Nome completo">
        <Input placeholder="NOME DO SÓCIO" {...u('nome')} />
      </Field>

      <div className="field-row">
        <Field label="Nacionalidade">
          <Input {...u('nacionalidade')} />
        </Field>
        <Field label="Nascimento">
          <Input placeholder="DD/MM/AAAA" {...u('nascimento')} />
        </Field>
      </div>

      <div className="field-row">
        <Field label="Estado Civil">
          <Input placeholder="casado..." {...u('estado_civil')} />
        </Field>
        <Field label="Regime de Bens">
          <Input placeholder="comunhão parcial..." {...u('regime')} />
        </Field>
      </div>

      <div className="field-row">
        <Field label="CPF">
          <Input placeholder="000.000.000-00" {...u('cpf')} />
        </Field>
        <Field label="RG / Órgão">
          <Input placeholder="0000000 — PC-GO" {...u('rg')} />
        </Field>
      </div>

      <Field label="Profissão">
        <Input {...u('profissao')} />
      </Field>

      <Field label="Endereço residencial">
        <Input placeholder="Rua, nº, bairro, cidade, UF, CEP" {...u('endereco')} />
      </Field>

      {/* Quotas e administração — só relevante para vigentes e novos */}
      {socio.papel !== 'retirante' && (
        <>
          <div className="field-row">
            <Field label="Quotas">
              <Input placeholder="60.000" {...u('quotas')} />
            </Field>
            <Field label="Valor das Quotas (R$)">
              <Input placeholder="60.000,00" {...u('quotas_valor')} />
            </Field>
          </div>
          <Field label="Administrador?">
            <Select value={socio.admin} onChange={(e) => updateSocio(socio.id, 'admin', e.target.value)}>
              <option value="sim">Sim</option>
              <option value="nao">Não</option>
            </Select>
          </Field>
        </>
      )}
    </div>
  );
}
