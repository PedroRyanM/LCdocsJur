import { create } from 'zustand';

export const MESES_PT = [
  'Janeiro','Fevereiro','Março','Abril','Maio','Junho',
  'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro',
];

function nextMesAno(meses) {
  if (!meses.length) {
    const now = new Date();
    return { mes: MESES_PT[now.getMonth()], ano: String(now.getFullYear()) };
  }
  const last   = meses[meses.length - 1];
  const mesIdx = MESES_PT.indexOf(last.mes);
  const ano    = parseInt(last.ano || new Date().getFullYear(), 10);
  return mesIdx === 11
    ? { mes: MESES_PT[0], ano: String(ano + 1) }
    : { mes: MESES_PT[mesIdx + 1], ano: String(ano) };
}

function buildMeses(n, startMonthsAgo = 0) {
  const now  = new Date();
  const rows = [];
  for (let i = startMonthsAgo + n - 1; i >= startMonthsAgo; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    rows.push({
      id:  Date.now() + i + Math.random(),
      mes: MESES_PT[d.getMonth()],
      ano: String(d.getFullYear()),
      valor: '',
    });
  }
  return rows;
}

const INITIAL_MES = () => {
  const now = new Date();
  return [{
    id:    Date.now(),
    mes:   MESES_PT[now.getMonth()],
    ano:   String(now.getFullYear()),
    valor: '',
  }];
};

export const useFaturamentoStore = create((set, get) => ({
  empresa_nome:      '',
  empresa_endereco:  '',
  empresa_cidade:    '',
  empresa_cnpj:      '',
  socio_nome:        '',
  logo:              null,   // { base64, mimetype }

  meses: INITIAL_MES(),

  assinatura_socio:    true,
  assinatura_contador: true,
  contador_crc:        '',

  cidade_assinatura: 'Goiânia',
  data_assinatura:   '',

  // ── Setters ───────────────────────────────────────────────
  setField: (key, value) => set({ [key]: value }),
  setLogo:  (data)       => set({ logo: data }),
  clearLogo:()           => set({ logo: null }),

  // ── Month management ──────────────────────────────────────
  addMes: () => {
    const { meses } = get();
    const next      = nextMesAno(meses);
    set({ meses: [...meses, { id: Date.now(), mes: next.mes, ano: next.ano, valor: '' }] });
  },

  removeMes: (id) => set(s => ({ meses: s.meses.filter(m => m.id !== id) })),

  updateMes: (id, key, value) => set(s => ({
    meses: s.meses.map(m => m.id === id ? { ...m, [key]: value } : m),
  })),

  autoFillFollowing: (id) => {
    const { meses } = get();
    const idx  = meses.findIndex(m => m.id === id);
    if (idx < 0) return;
    const updated = [...meses];
    for (let i = idx + 1; i < updated.length; i++) {
      const prev   = updated[i - 1];
      const mIdx   = MESES_PT.indexOf(prev.mes);
      if (mIdx < 0) break;
      updated[i] = mIdx === 11
        ? { ...updated[i], mes: MESES_PT[0], ano: String(parseInt(prev.ano,10)+1) }
        : { ...updated[i], mes: MESES_PT[mIdx+1], ano: prev.ano };
    }
    set({ meses: updated });
  },

  // ── Quick-fill n months ────────────────────────────────────
  gerarMeses: (n) => {
    set({ meses: buildMeses(n, 0) });
  },

  // ── Total ─────────────────────────────────────────────────
  getTotal: () => get().meses.reduce((acc, m) => {
    const n = parseFloat(String(m.valor||'0').replace(/[^\d,.-]/g,'').replace(',','.'));
    return acc + (isNaN(n) ? 0 : n);
  }, 0),

  // ── Prefill from documento store ─────────────────────────
  prefillFromDocumento: (doc) => set({
    empresa_nome:      doc.empresa_nome_atual || '',
    empresa_cnpj:      doc.empresa_cnpj       || '',
    empresa_endereco:  doc.sede_endereco      || '',
    empresa_cidade:    doc.sede_cidade
      ? `${doc.sede_cidade}${doc.sede_uf ? ' - ' + doc.sede_uf : ''}${doc.sede_cep ? ', CEP: ' + doc.sede_cep : ''}`
      : '',
    cidade_assinatura: doc.cidade_assinatura  || 'Goiânia',
  }),

  reset: () => set({
    empresa_nome: '', empresa_endereco: '', empresa_cidade: '', empresa_cnpj: '',
    socio_nome: '', logo: null, meses: INITIAL_MES(),
    assinatura_socio: true, assinatura_contador: true, contador_crc: '',
    cidade_assinatura: 'Goiânia', data_assinatura: '',
  }),
}));
