import { create } from 'zustand';

let _nextId = 1;

const newSocio = (overrides = {}) => ({
  id:           _nextId++,
  papel:        'vigente',   // 'vigente' | 'novo' | 'retirante'
  nome:         '',
  nacionalidade:'BRASILEIRA',
  nascimento:   '',
  estado_civil: '',
  regime:       '',
  cpf:          '',
  rg:           '',
  profissao:    'empresário',
  endereco:     '',
  quotas:       '',
  quotas_valor: '',
  admin:        'sim',
  ...overrides,
});

export const useSociosStore = create((set, get) => ({
  socios: [newSocio()],

  addSocio:    (data = {}) => set(s => ({ socios: [...s.socios, newSocio(data)] })),
  removeSocio: (id)        => set(s => ({ socios: s.socios.filter(sc => sc.id !== id) })),

  updateSocio: (id, key, value) => set(s => ({
    socios: s.socios.map(sc => sc.id === id ? { ...sc, [key]: value } : sc),
  })),

  getSocios: () => get().socios,

  // Helpers para o preview
  getSociosVigentes:  () => get().socios.filter(s => s.papel === 'vigente'),
  getSociosNovos:     () => get().socios.filter(s => s.papel === 'novo'),
  getSociosRetirantes:() => get().socios.filter(s => s.papel === 'retirante'),
  getSociosAtivos:    () => get().socios.filter(s => s.papel !== 'retirante'),
}));
