import { create } from 'zustand';
import { fetchClausulas } from '../services/api';

let _secaoCustomCount = 0;
let _clausulaLivreCount = 0;

export const useClausulasStore = create((set, get) => ({
  // From server
  definitions:  {},   // { [id]: clausula def }
  secoes:       {},   // { [id]: secao def } — base + custom merged
  defaultOrder: [],

  // Document state
  order:        [],   // ordered list of clause IDs
  texts:        {},   // { [id]: custom text }
  labels:       {},   // { [id]: custom label } — user-renamed clauses

  // Custom sections created by user
  customSecoes: {},   // { [id]: { id, label, ponte, numeracaoIndependente } }

  // UI
  loading:    false,
  editingId:  null,

  // ── Load ────────────────────────────────────────────────────
  load: async () => {
    set({ loading: true });
    try {
      const { clausulas, secoes, defaultOrder } = await fetchClausulas();
      set({
        definitions:  clausulas,
        secoes,
        defaultOrder,
        order:   [...defaultOrder],
        loading: false,
      });
    } catch (e) {
      console.error('Erro ao carregar cláusulas:', e);
      set({ loading: false });
    }
  },

  // ── getAllSecoes: base + custom merged ───────────────────────
  getAllSecoes: () => {
    const { secoes, customSecoes } = get();
    return { ...secoes, ...customSecoes };
  },

  // ── Custom section management ────────────────────────────────
  addSecaoCustom: (label = 'Nova Seção', ponte = '') => {
    _secaoCustomCount++;
    const id = `CUSTOM_${_secaoCustomCount}`;
    const nova = { id, label, ponte, numeracaoIndependente: true, custom: true };
    set(s => ({ customSecoes: { ...s.customSecoes, [id]: nova } }));
    return id;
  },

  updateSecao: (id, changes) => set(s => {
    const isBase   = !!s.secoes[id];
    const isCustom = !!s.customSecoes[id];
    if (isCustom) return { customSecoes: { ...s.customSecoes, [id]: { ...s.customSecoes[id], ...changes } } };
    if (isBase)   return { secoes:       { ...s.secoes,       [id]: { ...s.secoes[id],       ...changes } } };
    return s;
  }),

  removeSecaoCustom: (id) => set(s => {
    const next = { ...s.customSecoes };
    delete next[id];
    // Also remove all clauses belonging to this section
    const order = s.order.filter(clausId => {
      const def = s.definitions[clausId];
      return def ? def.secao !== id : true;
    });
    return { customSecoes: next, order };
  }),

  // ── Order management ─────────────────────────────────────────
  addClausula: (id, targetSecao = null) => {
    const { order, definitions } = get();
    if (!definitions[id]) return false;
    if (order.includes(id) && id !== 'CLAUSULA_LIVRE') return false;
    set({ order: [...order, id] });
    return true;
  },

  // Add a free-text clause to a specific section
  addClausulaLivre: (secaoId) => {
    _clausulaLivreCount++;
    const newId = `CLAUSULA_LIVRE_${_clausulaLivreCount}`;
    const def = {
      id:       newId,
      label:    'Cláusula Personalizada',
      secao:    secaoId || 'CONTRATO',
      numerada: true,
      removivel:true,
      texto:    '',
    };
    set(s => ({
      definitions: { ...s.definitions, [newId]: def },
      order:       [...s.order, newId],
    }));
    return newId;
  },

  removeClausula: (idx) => set(s => ({
    order: s.order.filter((_, i) => i !== idx),
  })),

  moveClausula: (fromIdx, toIdx) => set(s => {
    const next = [...s.order];
    const [item] = next.splice(fromIdx, 1);
    next.splice(toIdx, 0, item);
    return { order: next };
  }),

  // ── Text overrides ───────────────────────────────────────────
  setClausulaText:   (id, text) => set(s => ({ texts: { ...s.texts, [id]: text } })),
  resetClausulaText: (id)       => set(s => { const t = { ...s.texts }; delete t[id]; return { texts: t }; }),
  getClausulaText:   (id)       => {
    const { texts, definitions } = get();
    return texts[id] !== undefined ? texts[id] : (definitions[id]?.texto ?? '');
  },
  hasCustomText: (id) => get().texts[id] !== undefined,

  // ── Label overrides (rename) ─────────────────────────────────
  setClausulaLabel:   (id, label) => set(s => ({ labels: { ...s.labels, [id]: label } })),
  resetClausulaLabel: (id)        => set(s => { const l = { ...s.labels }; delete l[id]; return { labels: l }; }),
  getClausulaLabel:   (id)        => {
    const { labels, definitions } = get();
    return labels[id] !== undefined ? labels[id] : (definitions[id]?.label ?? id);
  },

  // ── Editor ───────────────────────────────────────────────────
  openEditor:  (id) => set({ editingId: id }),
  closeEditor: ()   => set({ editingId: null }),

  // ── Ordinals per section ─────────────────────────────────────
  getOrdinals: () => {
    const { order, definitions } = get();
    const counters = {};
    return order.map(id => {
      const def = definitions[id];
      if (!def?.numerada) return null;
      counters[def.secao] = (counters[def.secao] || 0) + 1;
      return counters[def.secao];
    });
  },
}));
