import { create } from 'zustand';

/**
 * docType: 'alteracao' | 'faturamento'
 * Controla qual template está ativo no editor.
 */
export const useDocTypeStore = create((set) => ({
  docType: 'alteracao',
  setDocType: (t) => set({ docType: t }),
}));
