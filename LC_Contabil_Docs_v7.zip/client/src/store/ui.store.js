import { create } from 'zustand';

export const useUiStore = create((set, get) => ({
  activeSection: 'empresa',
  toast: null,           // { message, type: 'success'|'error'|'info' }
  _toastTimer: null,

  setSection: (s) => set({ activeSection: s }),

  showToast: (message, type = 'info') => {
    const timer = get()._toastTimer;
    if (timer) clearTimeout(timer);
    const id = setTimeout(() => set({ toast: null }), 3200);
    set({ toast: { message, type }, _toastTimer: id });
  },

  clearToast: () => set({ toast: null }),
}));
