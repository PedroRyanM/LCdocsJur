import { create } from 'zustand';

const INITIAL = {
  // ── Documento ──────────────────────────────────────────────
  titulo_documento:   'ALTERAÇÃO DO CONTRATO SOCIAL DE',  // editável
  natureza_processo:  '',   // ex: "TRANSFORMAÇÃO EMPRESARIAL", "INCLUSÃO DE SÓCIO"

  // ── Empresa ────────────────────────────────────────────────
  empresa_nome_atual: '',
  empresa_nome_novo:  '',
  empresa_fantasia:   '',
  empresa_cnpj:       '',
  empresa_nire:       '',

  // ── Sede ───────────────────────────────────────────────────
  sede_endereco:      '',
  sede_bairro:        '',
  sede_cep:           '',
  sede_cidade:        '',
  sede_uf:            '',

  // ── Capital ────────────────────────────────────────────────
  cap_quotas:         '',
  cap_valor_quota:    '',
  cap_total:          '',

  // ── Objeto ────────────────────────────────────────────────
  objeto_social:      '',   // texto livre / CNAEs concatenados
  cnae_list:          [],   // [{ codigo, denominacao }]

  // ── Preâmbulo custom ───────────────────────────────────────
  // null = gerado automaticamente pelos sócios vigentes
  // string = texto personalizado
  preambulo_custom:        null,
  preambulo_fecho_custom:  null, // frase de fechamento do preâmbulo

  // ── Datas e foro ──────────────────────────────────────────
  data_inicio:        '',
  data_assinatura:    '',
  cidade_assinatura:  '',
  foro:               '',
};

export const useDocumentoStore = create((set, get) => ({
  ...INITIAL,
  logos: { client: null, contab: null, app: null },

  // Generic field setter
  setField: (key, value) => set({ [key]: value }),

  // CNAE list management
  addCnae: (cnae) => set(s => {
    if (s.cnae_list.find(c => c.codigo === cnae.codigo)) return s;
    const list = [...s.cnae_list, cnae];
    return { cnae_list: list, objeto_social: buildObjeto(list) };
  }),
  removeCnae: (codigo) => set(s => {
    const list = s.cnae_list.filter(c => c.codigo !== codigo);
    return { cnae_list: list, objeto_social: buildObjeto(list) };
  }),
  setObjetoManual: (text) => set({ objeto_social: text, cnae_list: [] }),

  // Logos
  setLogo: (slot, data) => set(s => ({ logos: { ...s.logos, [slot]: data } })),
  clearLogo: (slot) => set(s => ({ logos: { ...s.logos, [slot]: null } })),

  // Reset
  reset: () => set({ ...INITIAL, logos: { client: null, contab: null, app: null } }),

  // Computed: build vars object for preview/export
  getVars() {
    const s = get();
    const sede = [s.sede_endereco, s.sede_bairro, s.sede_cidade, s.sede_uf,
      s.sede_cep ? `CEP ${s.sede_cep}` : ''].filter(Boolean).join(', ');
    return { ...s, sede_completa: sede };
  },
}));

function buildObjeto(list) {
  return list.map(c => c.denominacao).join(', ');
}
