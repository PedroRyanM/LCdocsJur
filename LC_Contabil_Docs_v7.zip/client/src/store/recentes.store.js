import { create } from 'zustand';

const STORAGE_KEY = 'lc_contabil_recentes';
const MAX_RECENTES = 20;

function loadFromStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveToStorage(list) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {}
}

export const useRecentesStore = create((set, get) => ({
  recentes: loadFromStorage(),
  isOpen:   false,

  // ── Salvar snapshot do documento atual ─────────────────────
  salvarDocumento: (snapshot) => {
    const id        = snapshot.id || `doc_${Date.now()}`;
    const now       = new Date().toISOString();
    const entry     = { ...snapshot, id, updatedAt: now };
    const existing  = get().recentes;
    const filtered  = existing.filter(r => r.id !== id);
    const next      = [entry, ...filtered].slice(0, MAX_RECENTES);
    saveToStorage(next);
    set({ recentes: next });
    return id;
  },

  // ── Remover documento ───────────────────────────────────────
  removerDocumento: (id) => {
    const next = get().recentes.filter(r => r.id !== id);
    saveToStorage(next);
    set({ recentes: next });
  },

  // ── Limpar todos ────────────────────────────────────────────
  limparTodos: () => {
    saveToStorage([]);
    set({ recentes: [] });
  },

  // ── UI ──────────────────────────────────────────────────────
  openPanel:  () => set({ isOpen: true }),
  closePanel: () => set({ isOpen: false }),
  togglePanel:() => set(s => ({ isOpen: !s.isOpen })),
}));

/**
 * Constrói um snapshot do estado atual para persistir.
 * Recebe os dados de todos os stores relevantes.
 */
export function buildSnapshot({ doc, socios, clausulaOrder, clausulaTexts, id = null }) {
  return {
    id,
    titulo:        doc.titulo_documento || 'Sem título',
    empresa:       doc.empresa_nome_atual || 'Empresa não informada',
    cnpj:          doc.empresa_cnpj || '',
    natureza:      doc.natureza_processo || '',
    createdAt:     id ? undefined : new Date().toISOString(), // só na criação
    doc,
    socios,
    clausulaOrder,
    clausulaTexts,
  };
}
