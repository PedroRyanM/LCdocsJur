import { create } from 'zustand';

/**
 * Modificações disponíveis — cada uma gera cláusulas correspondentes.
 * A ordem aqui define a ordem padrão das cláusulas no documento.
 */
export const MODIFICACOES_CONFIG = [
  {
    id:      'transformacao',
    label:   'Transformação em LTDA',
    icon:    '🔄',
    desc:    'Transforma empresário individual em sociedade limitada',
    clausulas: ['TRANSFORMACAO'],
  },
  {
    id:      'nome',
    label:   'Alteração de Nome',
    icon:    '📝',
    desc:    'Muda denominação social e/ou nome fantasia',
    clausulas: ['NOME_EMPRESARIAL_ALT'],
  },
  {
    id:      'entrada_socio',
    label:   'Entrada de Sócio',
    icon:    '👤',
    desc:    'Admissão de novos sócios com cessão de quotas',
    clausulas: ['ENTRADA_SOCIO'],
  },
  {
    id:      'saida_socio',
    label:   'Saída de Sócio',
    icon:    '🚪',
    desc:    'Retirada de sócio e redistribuição de quotas',
    clausulas: ['SAIDA_SOCIO'],
  },
  {
    id:      'capital_social',
    label:   'Capital Social',
    icon:    '💰',
    desc:    'Altera o capital social e redistribui quotas',
    clausulas: ['CAPITAL_SOCIAL_ALT'],
  },
  {
    id:      'objeto_social',
    label:   'Objeto Social',
    icon:    '🏭',
    desc:    'Altera as atividades econômicas da empresa',
    clausulas: ['OBJETO_SOCIAL'],
  },
  {
    id:      'sede',
    label:   'Alteração de Sede',
    icon:    '📍',
    desc:    'Muda o endereço da sede social',
    clausulas: ['SEDE'],
  },
  {
    id:      'administracao',
    label:   'Administração',
    icon:    '👔',
    desc:    'Altera o(s) administrador(es) da sociedade',
    clausulas: ['ADMINISTRACAO'],
  },
  {
    id:      'filial',
    label:   'Abertura de Filial',
    icon:    '🏪',
    desc:    'Abre uma filial com endereço e atividades próprias',
    clausulas: ['FILIAL'],
  },
  {
    id:      'foro',
    label:   'Foro Eleito',
    icon:    '⚖️',
    desc:    'Define o foro para resolução de conflitos',
    clausulas: ['FORO_ALTERACAO'],
  },
  {
    id:      'clausulas_inalteradas',
    label:   'Cláusulas Inalteradas',
    icon:    '📌',
    desc:    'Declara que demais cláusulas permanecem vigentes',
    clausulas: ['CLAUSULAS_INALTERADAS'],
  },
  {
    id:      'consolidacao',
    label:   'Consolidação do Contrato',
    icon:    '📄',
    desc:    'Inclui a íntegra do contrato social consolidado',
    clausulas: ['CONSOLIDACAO_INICIO'],
  },
];

export const useModificacoesStore = create((set, get) => ({
  // Set of selected modification IDs
  selecionadas: new Set(['nome']),

  toggle: (id) => set(s => {
    const next = new Set(s.selecionadas);
    if (next.has(id)) next.delete(id);
    else              next.add(id);
    return { selecionadas: next };
  }),

  isSelected: (id) => get().selecionadas.has(id),

  // Returns ordered list of clausula IDs based on selected modifications
  getClausulasOrdem: () => {
    const { selecionadas } = get();
    const ids = [];
    for (const mod of MODIFICACOES_CONFIG) {
      if (selecionadas.has(mod.id)) {
        ids.push(...mod.clausulas);
      }
    }
    return ids;
  },

  setAll:   (ids) => set({ selecionadas: new Set(ids) }),
  clearAll: ()    => set({ selecionadas: new Set() }),
}));
