import React, { useEffect } from 'react';
import { useClausulasStore } from '@/store/clausulas.store';
import { useExport }         from '@/hooks/useExport';
import { ModalProvider }     from '@/components/ui/Modal';

import { Header }        from '@/components/layout/Header';
import { DocTypeBar }    from '@/components/layout/DocTypeBar';
import { NavTabs }       from '@/components/layout/NavTabs';
import { RecentesPanel } from '@/components/layout/RecentesPanel';
import { FormPanel }     from '@/components/editor/FormPanel';
import { PreviewPanel }  from '@/components/editor/preview/PreviewPanel';
import { Toast }         from '@/components/ui/Toast';

import styles from './App.module.css';

export default function App() {
  const loadClausulas = useClausulasStore(s => s.load);
  const { loading, handleExportDocx, handleExportPdf } = useExport();

  useEffect(() => { loadClausulas(); }, [loadClausulas]);

  return (
    <ModalProvider>
      <div className={styles.app}>
        {/* Fixed top header */}
        <Header
          onExportDocx={handleExportDocx}
          onExportPdf={handleExportPdf}
          exportLoading={loading}
        />

        {/* Document type selector — sits below header */}
        <DocTypeBar />

        <div className={styles.shell}>
          <div className={styles.sidebar}>
            {/* Section tabs (hidden for faturamento) */}
            <NavTabs />
            {/* Form content */}
            <FormPanel />
          </div>

          <PreviewPanel
            onExportDocx={handleExportDocx}
            onExportPdf={handleExportPdf}
            exportLoading={loading}
          />
        </div>

        <RecentesPanel />
        <Toast />
      </div>
    </ModalProvider>
  );
}
