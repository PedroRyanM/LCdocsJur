const BASE = import.meta.env.VITE_API_URL || '';

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, options);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || 'Erro na requisição');
  }
  return res;
}

// ── Cláusulas ─────────────────────────────────────────────────────────────────
export async function fetchClausulas() {
  const r = await request('/api/clausulas');
  return r.json();
}

// ── CNAE ──────────────────────────────────────────────────────────────────────
export async function searchCnae(q, limit = 30) {
  const r = await request(`/api/cnae/search?q=${encodeURIComponent(q)}&limit=${limit}`);
  return r.json();
}

// ── Upload ────────────────────────────────────────────────────────────────────
export async function uploadLogo(file) {
  const fd = new FormData();
  fd.append('logo', file);
  const r = await request('/api/upload/logo', { method: 'POST', body: fd });
  return r.json();
}

// ── Export ────────────────────────────────────────────────────────────────────
export async function exportDocx(payload) {
  const r = await request('/api/export/docx', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(payload),
  });
  return r.blob();
}

export async function exportPdf(html) {
  const r = await request('/api/export/pdf', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ html }),
  });
  return r.blob();
}

// ── Helper: trigger browser download ─────────────────────────────────────────
export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a   = document.createElement('a');
  a.href     = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ── Faturamento ───────────────────────────────────────────────────────────────
export async function exportFaturamentoDocx(data) {
  const r = await request('/api/faturamento/export', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(data),
  });
  return r.blob();
}
