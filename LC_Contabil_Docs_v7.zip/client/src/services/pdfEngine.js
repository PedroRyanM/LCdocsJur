/**
 * pdfEngine.js — Motor PDF próprio, 100% client-side.
 *
 * Estratégia de captura:
 *  1. Clona o elemento #doc-preview num container off-screen com largura fixa (794px = A4)
 *  2. Captura com html2canvas em escala 2× (qualidade retina)
 *  3. Pagina o canvas em folhas A4 via jsPDF
 *
 * Isso garante que o PDF seja idêntico ao documento independente
 * do tamanho da janela do usuário.
 */

const A4_W_MM     = 210;
const A4_H_MM     = 297;
const MARGIN_MM   = 15;
const DOC_PX_W    = 794;   // A4 width at 96dpi — mesma largura do elemento .page
const SCALE       = 2;     // resolução 2× para qualidade

export async function generatePdf(filename = 'documento.pdf') {
  const [{ default: jsPDF }, { default: html2canvas }] = await Promise.all([
    import('jspdf'),
    import('html2canvas'),
  ]);

  const sourceEl = document.getElementById('doc-preview');
  if (!sourceEl) throw new Error('Elemento #doc-preview não encontrado');

  const toast = _showToast('Gerando PDF…');

  try {
    // ── 1. Cria container off-screen com largura A4 fixa ─────────
    const wrapper = document.createElement('div');
    wrapper.style.cssText = `
      position: fixed;
      left: -9999px;
      top: 0;
      width: ${DOC_PX_W}px;
      background: #fff;
      z-index: -1;
      pointer-events: none;
    `;

    // Clona o elemento preservando estilos computados
    const clone = sourceEl.cloneNode(true);
    clone.style.cssText = `
      width: ${DOC_PX_W}px;
      min-width: ${DOC_PX_W}px;
      max-width: ${DOC_PX_W}px;
      box-shadow: none;
      border-radius: 0;
      margin: 0;
      padding: 60px 70px;
      background: #ffffff;
      font-family: 'Times New Roman', Times, serif;
      font-size: 12.25px;
      line-height: 1.80;
      color: #1C1209;
    `;

    wrapper.appendChild(clone);
    document.body.appendChild(wrapper);

    // Aguarda fonts renderizarem
    await document.fonts.ready;
    await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

    // ── 2. Captura com html2canvas ───────────────────────────────
    const canvas = await html2canvas(clone, {
      scale:           SCALE,
      useCORS:         true,
      allowTaint:      true,
      backgroundColor: '#ffffff',
      logging:         false,
      imageTimeout:    8000,
      width:           DOC_PX_W,
      windowWidth:     DOC_PX_W,
    });

    // Remove o clone
    document.body.removeChild(wrapper);

    // ── 3. Cria PDF A4 ───────────────────────────────────────────
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit:        'mm',
      format:      'a4',
      compress:    true,
    });

    const contentW    = A4_W_MM - MARGIN_MM * 2;
    const imgW        = contentW;
    const imgH        = (canvas.height / canvas.width) * imgW;
    const pageContentH= A4_H_MM - MARGIN_MM * 2;

    let yOffset = 0;
    let pageNum = 0;

    while (yOffset < imgH) {
      if (pageNum > 0) pdf.addPage();

      const sliceH    = Math.min(pageContentH, imgH - yOffset);
      const srcY      = Math.round((yOffset / imgH) * canvas.height);
      const srcH      = Math.round((sliceH  / imgH) * canvas.height);

      // Slice do canvas para esta página
      const slice     = document.createElement('canvas');
      slice.width     = canvas.width;
      slice.height    = Math.max(1, srcH);
      const ctx       = slice.getContext('2d');
      ctx.fillStyle   = '#ffffff';
      ctx.fillRect(0, 0, slice.width, slice.height);
      ctx.drawImage(canvas, 0, srcY, canvas.width, srcH, 0, 0, canvas.width, srcH);

      pdf.addImage(
        slice.toDataURL('image/jpeg', 0.95),
        'JPEG',
        MARGIN_MM, MARGIN_MM,
        imgW, sliceH,
        undefined, 'FAST'
      );

      yOffset += pageContentH;
      pageNum++;
    }

    pdf.save(filename);

  } finally {
    _hideToast(toast);
  }
}

// ── Toast helpers ─────────────────────────────────────────────────────────────
function _showToast(msg) {
  // Inject spin keyframe once
  if (!document.getElementById('__pdf_engine_style__')) {
    const s = document.createElement('style');
    s.id = '__pdf_engine_style__';
    s.textContent = `
      @keyframes __pdf_spin { to { transform: rotate(360deg); } }
      @keyframes __pdf_fadein { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
    `;
    document.head.appendChild(s);
  }
  const el = document.createElement('div');
  el.id = '__pdf_toast__';
  el.style.cssText = `
    position:fixed;bottom:24px;right:24px;z-index:99999;
    background:#2A1A10;color:#F5EAD8;
    padding:12px 20px;border-radius:8px;
    font-family:'DM Sans',sans-serif;font-size:0.84rem;font-weight:500;
    box-shadow:0 8px 24px rgba(0,0,0,0.40);
    display:flex;align-items:center;gap:10px;
    animation:__pdf_fadein 0.25s ease;
  `;
  const spin = document.createElement('span');
  spin.style.cssText = `
    width:14px;height:14px;
    border:2px solid rgba(245,234,216,0.25);
    border-top-color:#D4A870;
    border-radius:50%;
    animation:__pdf_spin 0.7s linear infinite;
    display:inline-block;flex-shrink:0;
  `;
  el.appendChild(spin);
  el.appendChild(document.createTextNode(msg));
  document.body.appendChild(el);
  return el;
}
function _hideToast(el) {
  if (!el?.parentNode) return;
  el.style.transition = 'all 0.2s ease';
  el.style.opacity = '0';
  el.style.transform = 'translateY(8px)';
  setTimeout(() => el.parentNode?.removeChild(el), 220);
}
